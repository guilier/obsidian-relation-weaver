var obsidian = require('obsidian');
var debounce = obsidian.debounce;

var VIEW_TYPE = 'my-char-view';

// ========== 亲密度配置（支持自定义）==========
var DEFAULT_INTIMACY_LEVELS = [
    { value: -3, label: '仇恨', color: '#c0392b' },
    { value: -2, label: '厌恶', color: '#e67e22' },
    { value: -1, label: '冷淡', color: '#f39c12' },
    { value: 0, label: '陌生', color: '#95a5a6' },
    { value: 1, label: '认识', color: '#4a90e2' },
    { value: 2, label: '一般', color: '#2ecc71' },
    { value: 3, label: '友好', color: '#27ae60' },
    { value: 4, label: '亲密', color: '#e74c3c' },
    { value: 5, label: '挚友/至亲', color: '#9b59b6' }
];
var INTIMACY_LEVELS = DEFAULT_INTIMACY_LEVELS.slice();

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function updateIntimacyLevels(customStr) {
    if (!customStr || !customStr.trim()) {
        INTIMACY_LEVELS = DEFAULT_INTIMACY_LEVELS.slice();
        return;
    }
    try {
        var parts = customStr.split(',').map(function(s) { return s.trim(); });
        var newLevels = [];
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].split(':');
            if (p.length >= 3) {
                newLevels.push({
                    value: parseInt(p[0]),
                    label: p[1],
                    color: p[2]
                });
            }
        }
        if (newLevels.length > 0) {
            INTIMACY_LEVELS = newLevels;
        }
    } catch(e) {
        console.log('自定义亲密度解析失败:', e);
    }
}

function getIntimacyLabel(value) {
    for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
        if (INTIMACY_LEVELS[i].value === value) return INTIMACY_LEVELS[i].label;
    }
    return '认识';
}

function getIntimacyColor(value) {
    for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
        if (INTIMACY_LEVELS[i].value === value) return INTIMACY_LEVELS[i].color;
    }
    return '#4a90e2';
}

// ========== 默认事件标签配置 ==========
var DEFAULT_EVENT_TAGS = [
    { value: '朝堂', label: '朝堂', color: '#e74c3c' },
    { value: '博弈', label: '博弈', color: '#9b59b6' },
    { value: '感情', label: '感情', color: '#e91e63' },
    { value: '出场', label: '出场', color: '#2ecc71' },
    { value: '死亡', label: '死亡', color: '#7f8c8d' },
    { value: '诸侯', label: '诸侯', color: '#3498db' },
    { value: '日常', label: '📚 日常', color: '#16a085' },
    { value: '其他', label: '其他', color: '#95a5a6' }
];

// ========== 【修复】直接使用保存的标签，不再强制合并默认标签 ==========
function getEventTags(plugin) {
    var customTags = plugin.settings.customEventTags || [];
    
    // 如果没有任何标签，使用默认标签作为初始值
    if (customTags.length === 0) {
        return JSON.parse(JSON.stringify(DEFAULT_EVENT_TAGS));
    }
    
    // 直接返回保存的标签列表，不做任何合并
    return JSON.parse(JSON.stringify(customTags));
}

function getTagMap(plugin) {
    if (!plugin._tagMapCache) {
        var map = {};
        var tags = getEventTags(plugin);
        for (var i = 0; i < tags.length; i++) {
            map[tags[i].value] = tags[i];
        }
        plugin._tagMapCache = map;
    }
    return plugin._tagMapCache;
}

function invalidateTagCache(plugin) {
    plugin._tagMapCache = null;
}

function getTagLabel(plugin, tagValue) {
    var tag = getTagMap(plugin)[tagValue];
    return tag ? tag.label : (tagValue || '其他');
}

function getTagColor(plugin, tagValue) {
    var tag = getTagMap(plugin)[tagValue];
    return tag ? tag.color : '#95a5a6';
}

function exportToJSON(data, filename) {
    var jsonStr = JSON.stringify(data, null, 2);
    var blob = new Blob([jsonStr], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

function importFromJSON(file, callback) {
    var reader = new FileReader();
    reader.onload = function(e) {
        try {
            var data = JSON.parse(e.target.result);
            callback(data);
        } catch (err) {
            new obsidian.Notice('JSON解析失败');
        }
    };
    reader.readAsText(file);
}

function getDataPath(plugin) {
    return plugin.app.vault.configDir + '/plugins/' + plugin.manifest.id + '/data.json';
}

async function loadSavedData(plugin) {
    var path = getDataPath(plugin);
    try {
        if (await plugin.app.vault.adapter.exists(path)) {
            var content = await plugin.app.vault.adapter.read(path);
            return JSON.parse(content);
        }
    } catch (e) {
        console.log('读取数据文件失败:', e);
    }
    return { factions: [], relations: [] };
}

async function saveData(plugin, data) {
    var path = getDataPath(plugin);
    try {
        var dir = plugin.app.vault.configDir + '/plugins/' + plugin.manifest.id;
        if (!await plugin.app.vault.adapter.exists(dir)) {
            await plugin.app.vault.adapter.mkdir(dir);
        }
        await plugin.app.vault.adapter.write(path, JSON.stringify(data, null, 2));
    } catch (e) {
        console.log('保存数据失败:', e);
    }
}

function getCharFullPath(plugin) {
    var folder = plugin.settings.charFolder || '';
    var filename = plugin.settings.charFile || '人物索引.md';
    if (folder) {
        var cleanFolder = folder.replace(/^\/+/, '').replace(/\/+$/, '');
        if (cleanFolder) {
            return cleanFolder + '/' + filename;
        }
    }
    return filename;
}

function getTimelineFullPath(plugin) {
    var folder = plugin.settings.timelineFolder || '';
    var filename = plugin.settings.timelineFile || '时间线.md';
    if (folder) {
        var cleanFolder = folder.replace(/^\/+/, '').replace(/\/+$/, '');
        if (cleanFolder) {
            return cleanFolder + '/' + filename;
        }
    }
    return filename;
}

function createOption(value, text) {
    var opt = document.createElement('option');
    opt.value = value;
    opt.textContent = text;
    return opt;
}

// ========== 历史时间解析 ==========
function parseHistoricalDate(str) {
    if (!str || !String(str).trim()) return null;
    var s = String(str).trim();

    var bcMatch = s.match(/(?:公元前|前|BC|B\.C\.?)\s*(\d+(?:\.\d+)?)\s*(?:年)?/i);
    if (bcMatch) {
        var bcYear = parseFloat(bcMatch[1]);
        return { sortValue: -bcYear, display: s, era: 'bc', year: bcYear };
    }

    var adMatch = s.match(/(?:公元|AD|A\.D\.?)\s*(\d+(?:\.\d+)?)\s*(?:年)?/i);
    if (adMatch) {
        var adYear = parseFloat(adMatch[1]);
        return { sortValue: adYear, display: s, era: 'ad', year: adYear };
    }

    var yearMatch = s.match(/^(\d+(?:\.\d+)?)\s*年$/);
    if (yearMatch) {
        var y1 = parseFloat(yearMatch[1]);
        return { sortValue: y1, display: s, era: 'ad', year: y1 };
    }

    var numMatch = s.match(/^(\d+(?:\.\d+)?)$/);
    if (numMatch) {
        var y2 = parseFloat(numMatch[1]);
        return { sortValue: y2, display: s, era: 'ad', year: y2 };
    }

    return { sortValue: null, display: s, era: 'unknown', raw: s };
}

function formatSortValue(sortValue) {
    if (sortValue === null || sortValue === undefined || isNaN(sortValue)) return '?';
    if (sortValue < 0) return '前' + Math.abs(Math.round(sortValue)) + '年';
    if (sortValue === 0) return '公元元年';
    return Math.round(sortValue) + '年';
}

function findCharsInEvent(eventText, charNames) {
    var sorted = charNames.slice().sort(function(a, b) { return b.length - a.length; });
    var found = [];
    var usedRanges = [];

    for (var i = 0; i < sorted.length; i++) {
        var name = sorted[i];
        var idx = 0;
        while ((idx = eventText.indexOf(name, idx)) !== -1) {
            var end = idx + name.length;
            var overlap = false;
            for (var r = 0; r < usedRanges.length; r++) {
                if (!(end <= usedRanges[r].start || idx >= usedRanges[r].end)) {
                    overlap = true;
                    break;
                }
            }
            if (!overlap) {
                found.push(name);
                usedRanges.push({ start: idx, end: end });
                break;
            }
            idx++;
        }
    }
    return found;
}

function validateImportData(data) {
    if (!data || typeof data !== 'object') return { ok: false, error: '无效的数据格式' };
    if (data.factions !== undefined) {
        if (!Array.isArray(data.factions)) return { ok: false, error: 'factions 必须是数组' };
        for (var i = 0; i < data.factions.length; i++) {
            if (!data.factions[i].name) return { ok: false, error: '阵营第 ' + (i + 1) + ' 项缺少 name' };
        }
    }
    if (data.relations !== undefined) {
        if (!Array.isArray(data.relations)) return { ok: false, error: 'relations 必须是数组' };
        for (var j = 0; j < data.relations.length; j++) {
            var rel = data.relations[j];
            if (!rel.charA || !rel.charB) return { ok: false, error: '关系第 ' + (j + 1) + ' 项缺少 charA 或 charB' };
        }
    }
    return { ok: true };
}

function openCharView(app) {
    var leaf = app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
        app.workspace.getRightLeaf(false).setViewState({ type: VIEW_TYPE, active: true });
    } else {
        app.workspace.revealLeaf(leaf);
    }
}

function refreshCharView(app, options) {
    options = options || {};
    var leaves = app.workspace.getLeavesOfType(VIEW_TYPE);
    if (leaves.length > 0) {
        var view = leaves[0].view;
        if (view && view.loadAllData) {
            view.loadAllData(options).then(function() { view.render(); });
        }
    }
}

function getCharLifecycle(view, char) {
    var settings = view.plugin.settings;
    var birth = view.getFieldValue(char, settings.birthFieldNames || '出生,出生时间');
    var death = view.getFieldValue(char, settings.deathFieldNames || '死亡,死亡时间');
    var firstAppear = view.getFieldValue(char, settings.firstAppearFieldName || '首次出场');
    return {
        birth: birth,
        death: death,
        firstAppear: firstAppear,
        birthParsed: parseHistoricalDate(birth),
        deathParsed: parseHistoricalDate(death),
        firstAppearParsed: parseHistoricalDate(firstAppear)
    };
}

// ========== 视图 ==========
var MyView = /** @class */ (function (_super) {
    __extends(MyView, _super);
    function MyView(leaf, plugin) {
        var _this = _super.call(this, leaf) || this;
        _this.plugin = plugin;
        _this.chars = [];
        _this.timeline = [];
        _this.factions = [];
        _this.relations = [];
        _this.tab = 'chars';
        _this.searchText = '';
        _this.expandedFactions = {};
        _this.selectedTag = '';
        _this.relationFilterType = 'all';
        _this.relationFilterIntimacy = 'all';
        _this.relationSortBy = 'intimacy';
        _this.relationViewMode = 'list';
        _this.expandedRelationGroups = {};
        _this._rendering = false;
        _this.lifecycleSortBy = 'birth';
        _this.lifecycleSortOrder = 'asc';
        _this.lifecycleOnlyDated = false;
        _this.charMap = {};
        _this.appearCounts = {};
        _this.relationCounts = {};
        _this.charNames = [];
        return _this;
    }
    MyView.prototype.getViewType = function () { return VIEW_TYPE; };
    MyView.prototype.getDisplayText = function () { return '人物关系谱系'; };
    MyView.prototype.getIcon = function () { return 'users'; };

    MyView.prototype.onOpen = function () {
        var self = this;
        this.contentEl.empty();
        this.contentEl.addClass('my-char-view-root');
        this.loadAllData().then(function() {
            self.render();
        });
    };

    MyView.prototype.getCharField = function (charData, fieldName) {
        return charData.fields ? charData.fields[fieldName] : '';
    };

    MyView.prototype.getFieldValue = function (charData, fieldNames) {
        if (!fieldNames) return '';
        var names = Array.isArray(fieldNames) ? fieldNames : fieldNames.split(',');
        for (var i = 0; i < names.length; i++) {
            var val = this.getCharField(charData, names[i].trim());
            if (val) return val;
        }
        return '';
    };

    MyView.prototype.render = function () {
        if (this._rendering) {
            return;
        }
        this._rendering = true;
        
        var container = this.contentEl;
        container.empty();
        container.addClass('my-char-view-root');

        var self = this;

        var headerRow = container.createEl('div', { cls: 'my-char-view-header' });
        
        headerRow.createEl('h2', { text: '人物关系谱系' });
        
        if (this.tab !== 'chars') {
            var backBtn = headerRow.createEl('button', { text: '🏠 返回主页', cls: 'my-char-view-btn my-char-view-btn-secondary' });
            backBtn.addEventListener('click', function() {
                self.tab = 'chars';
                self.searchText = '';
                self.selectedTag = '';
                self.render();
            });
        }

        var toolbar = container.createEl('div', { cls: 'my-char-view-toolbar' });

        var refreshBtn = toolbar.createEl('button', { text: '🔄 刷新数据', cls: 'my-char-view-btn' });
        refreshBtn.addEventListener('click', function() {
            self.loadAllData().then(function() { self.render(); });
        });

        var applyConfigBtn = toolbar.createEl('button', { text: '应用字段设置', cls: 'my-char-view-btn my-char-view-btn-success' });
        applyConfigBtn.addEventListener('click', function() {
            self.loadAllData().then(function() { self.render(); });
            new obsidian.Notice('已重新加载并应用字段设置');
        });

        toolbar.createEl('span', {
            text: '人物:' + this.chars.length + ' | 阵营:' + this.factions.length + ' | 关系:' + this.relations.length,
            cls: 'my-char-view-stats'
        });

        var tabs = container.createEl('div', { cls: 'my-char-view-tabs' });

        var tabNames = [
            { id: 'chars', label: '👥 人物' },
            { id: 'factions', label: '🏰 阵营' },
            { id: 'relations', label: '🔗 关系' },
            { id: 'timeline', label: '📅 时间线' },
            { id: 'lifecycle', label: '⏳ 生命周期' },
            { id: 'statistics', label: '📊 统计' },
            { id: 'importexport', label: '💾 导入导出' }
        ];

        for (var i = 0; i < tabNames.length; i++) {
            (function (tab) {
                var btn = tabs.createEl('button', { text: tab.label });
                btn.className = 'my-char-view-tab-btn' + (self.tab === tab.id ? ' is-active' : '');
                btn.addEventListener('click', function() {
                    self.tab = tab.id;
                    self.searchText = '';
                    self.selectedTag = '';
                    self.render();
                });
            })(tabNames[i]);
        }

        var content = container.createEl('div', { cls: 'my-char-view-content' });

        if (this.chars.length === 0 && this.tab !== 'importexport') {
            content.createEl('p', { text: '点击"刷新数据"加载文件', cls: 'my-char-view-empty' });
        } else {
            try {
                this.renderCurrentTab(content);
            } catch (err) {
                throw err;
            }
        }
        
        this._rendering = false;
    };

    MyView.prototype.renderCurrentTab = function (container) {
        container.empty();
        var tabContent = container.createEl('div');
        tabContent.className = 'tab-content';
        tabContent.style.cssText = 'flex:1;overflow-y:auto;min-height:0;';
        
        switch (this.tab) {
            case 'chars': this.renderChars(tabContent); break;
            case 'factions': this.renderFactions(tabContent); break;
            case 'relations': this.renderRelations(tabContent); break;
            case 'timeline': this.renderTimeline(tabContent); break;
            case 'lifecycle': this.renderLifecycle(tabContent); break;
            case 'statistics': this.renderStatistics(tabContent); break;
            case 'importexport': this.renderImportExport(tabContent); break;
            default: this.renderChars(tabContent);
        }
    };

    MyView.prototype.loadAllData = async function (options) {
        options = options || {};
        var silent = !!options.silent;
        
        if (this.plugin.settings.charFile) {
            var fullCharPath = getCharFullPath(this.plugin);
            var charFile = this.app.vault.getAbstractFileByPath(fullCharPath);
            if (charFile) {
                var charContent = await this.app.vault.read(charFile);
                this.chars = this.parseChars(charContent);
            } else if (!silent) {
                console.log('人物文件未找到:', fullCharPath);
                new obsidian.Notice('未找到人物文件: ' + fullCharPath);
            }
        }

        if (this.plugin.settings.timelineFile) {
            var fullTimelinePath = getTimelineFullPath(this.plugin);
            var timelineFile = this.app.vault.getAbstractFileByPath(fullTimelinePath);
            if (timelineFile) {
                var timelineContent = await this.app.vault.read(timelineFile);
                this.timeline = this.parseTimeline(timelineContent);
            } else if (!silent) {
                console.log('时间线文件未找到:', fullTimelinePath);
                new obsidian.Notice('未找到时间线文件: ' + fullTimelinePath);
            }
        }

        var savedData = await loadSavedData(this.plugin);
        this.factions = savedData.factions || [];
        this.relations = savedData.relations || [];

        if (this.plugin.settings.customIntimacyLevels) {
            updateIntimacyLevels(this.plugin.settings.customIntimacyLevels);
        }

        invalidateTagCache(this.plugin);
        this.buildIndexes();

        if (!silent) {
            new obsidian.Notice('加载完成：' + this.chars.length + '人物，' + this.factions.length + '阵营，' + this.relations.length + '关系');
        }
    };

    MyView.prototype.buildIndexes = function () {
        this.charMap = {};
        this.appearCounts = {};
        this.relationCounts = {};
        this.charNames = [];

        for (var i = 0; i < this.chars.length; i++) {
            var c = this.chars[i];
            this.charMap[c.name] = c;
            this.appearCounts[c.name] = 0;
            this.relationCounts[c.name] = 0;
            this.charNames.push(c.name);
        }

        for (var ti = 0; ti < this.timeline.length; ti++) {
            var appeared = findCharsInEvent(this.timeline[ti].event, this.charNames);
            for (var ai = 0; ai < appeared.length; ai++) {
                this.appearCounts[appeared[ai]]++;
            }
        }

        for (var ri = 0; ri < this.relations.length; ri++) {
            var r = this.relations[ri];
            if (this.relationCounts[r.charA] !== undefined) this.relationCounts[r.charA]++;
            if (this.relationCounts[r.charB] !== undefined) this.relationCounts[r.charB]++;
        }
    };

    MyView.prototype.parseChars = function (content) {
        var chars = [];
        var lines = content.split('\n');
        var current = null;

        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (!line) continue;
          
            if (line.startsWith('## ') && !line.startsWith('### ')) {
                if (current && current.name) chars.push(current);
                current = { name: line.substring(3).trim(), fields: {} };
                continue;
            }
          
            if (line.startsWith('# ')) continue;
            if (line.startsWith('---')) continue;
          
            if (current) {
                var text = line;
                var hasDash = line.startsWith('- ');
                if (hasDash) {
                    text = line.substring(2);
                }
              
                var sep = text.indexOf('：');
                if (sep === -1) sep = text.indexOf(':');
              
                if (sep !== -1) {
                    var key = text.substring(0, sep).trim();
                    var value = text.substring(sep + 1).trim();
                    if (value !== undefined) {
                        current.fields[key] = value;
                    }
                }
            }
        }
        if (current && current.name) chars.push(current);
        return chars;
    };

    MyView.prototype.parseTimeline = function (content) {
        var records = [];
        var lines = content.split('\n');
        var currentYear = '';
        var currentMonth = '';

        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            var trimmedLine = line.trim();
            
            if (!trimmedLine) continue;
            if (trimmedLine.startsWith('# ') && !trimmedLine.startsWith('## ')) continue;
            
            if (trimmedLine.startsWith('## ') && !trimmedLine.startsWith('### ')) {
                currentYear = trimmedLine.substring(3).trim();
                currentMonth = '';
                continue;
            }
            
            if (trimmedLine.startsWith('### ')) {
                currentMonth = trimmedLine.substring(4).replace(/[：:]/g, '').trim();
                continue;
            }
            
            if (currentYear && (trimmedLine.startsWith('- ') || trimmedLine.startsWith('* '))) {
                var eventText = trimmedLine.substring(1).trim();
                
                if (eventText) {
                    var tag = '';
                    var tagMatch = eventText.match(/^\[([^\]]+)\]\s*/);
                    if (tagMatch) {
                        tag = tagMatch[1];
                        eventText = eventText.substring(tagMatch[0].length);
                    }
                    
                    records.push({ 
                        year: currentYear, 
                        month: currentMonth || '未标注', 
                        event: eventText, 
                        tag: tag 
                    });
                }
            }
        }
        
        return records;
    };

    MyView.prototype.saveFactionsAndRelations = async function () {
        await saveData(this.plugin, {
            factions: this.factions,
            relations: this.relations
        });
    };

    // ========== 人物视图 ==========
    MyView.prototype.renderChars = function (container) {
        var self = this;
        var settings = this.plugin.settings;
        var factionField = settings.factionFieldName || '阵营';
        var deathFieldNames = settings.deathFieldNames || '死亡,死亡时间';
        var firstAppearField = settings.firstAppearFieldName || '首次出场';
        var intimateField = settings.intimateFieldName || '亲密人物';

        var searchBar = container.createEl('div');
        searchBar.style.cssText = 'margin-bottom:10px;flex-shrink:0;';
        var searchInput = searchBar.createEl('input', {
            type: 'text',
            placeholder: '搜索人物名、身份、阵营、死亡...'
        });
        searchInput.style.cssText = 'width:100%;padding:8px;border:1px solid var(--background-modifier-border);border-radius:4px;font-size:14px;box-sizing:border-box;';
        searchInput.className = 'my-char-view-search';
        searchInput.value = this.searchText;
        searchInput.addEventListener('input', debounce(function () {
            self.searchText = searchInput.value;
            self.renderCurrentTab(container.parentElement);
        }, 200));

        var filtered = this.chars;
        if (this.searchText) {
            var kw = this.searchText.toLowerCase();
            filtered = this.chars.filter(function (c) {
                var searchStr = c.name.toLowerCase() + ' ' + JSON.stringify(c.fields).toLowerCase();
                return searchStr.indexOf(kw) !== -1;
            });
        }

        var groups = {};
        for (var i = 0; i < filtered.length; i++) {
            var f = this.getCharField(filtered[i], factionField) || '未分配阵营';
            if (!groups[f]) groups[f] = [];
            groups[f].push(filtered[i]);
        }

        var groupNames = Object.keys(groups).sort();
        for (var gi = 0; gi < groupNames.length; gi++) {
            var gname = groupNames[gi];
            var members = groups[gname];

            container.createEl('h3', { text: gname + ' (' + members.length + '人)' })
                .style.cssText = 'margin:10px 0 6px;padding:6px 10px;background:#f0f4ff;border-radius:4px;font-size:14px;';

            for (var j = 0; j < members.length; j++) {
                var c = members[j];
                var card = container.createEl('div', { cls: 'my-char-view-card' });

                var appearCount = self.appearCounts[c.name] || 0;
                var relCount = self.relationCounts[c.name] || 0;

                var identity = this.getCharField(c, '身份');
                var death = this.getFieldValue(c, deathFieldNames);
                var firstAppear = this.getCharField(c, firstAppearField);
                var intimate = this.getCharField(c, intimateField);

                var titleEl = card.createEl('strong');
                titleEl.style.fontSize = '15px';
                titleEl.textContent = c.name;
                if (identity) {
                    var idEl = card.createEl('small');
                    idEl.className = 'my-char-view-muted';
                    idEl.textContent = ' ' + identity;
                }
                if (death) {
                    var deathEl = card.createEl('span');
                    deathEl.style.cssText = 'background:var(--background-modifier-border);padding:1px 6px;border-radius:8px;font-size:10px;margin-left:4px;';
                    deathEl.textContent = '💀' + death;
                }
                card.createEl('br');
                var metaEl = card.createEl('small', { cls: 'my-char-view-muted' });
                var metaText = '出场 ' + appearCount + '次 | 关系 ' + relCount + '个';
                if (firstAppear) metaText += ' | 首次: ' + firstAppear;
                if (intimate) metaText += ' | 亲密: ' + intimate;
                metaEl.textContent = metaText;

                (function (charData, view) {
                    card.addEventListener('click', function () {
                        view.showCharDetail(charData);
                    });
                })(c, this);
            }
        }
    };

    // ========== 阵营视图 ==========
    MyView.prototype.renderFactions = function (container) {
        var self = this;
        var settings = this.plugin.settings;
        var factionField = settings.factionFieldName || '阵营';

        var headerBar = container.createEl('div');
        headerBar.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px;flex-shrink:0;';

        headerBar.createEl('h3', { text: '阵营管理' }).style.cssText = 'margin:0;';

        var btnGroup = headerBar.createEl('div');
        btnGroup.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap;';

        var expandAllBtn = btnGroup.createEl('button', { text: '全部展开' });
        expandAllBtn.style.cssText = 'padding:6px 10px;border:1px solid #ddd;border-radius:4px;cursor:pointer;font-size:12px;background:white;';
        expandAllBtn.addEventListener('click', function () {
            for (var i = 0; i < self.factions.length; i++) {
                self.expandedFactions[self.factions[i].name] = true;
            }
            self.renderCurrentTab(container.parentElement);
        });

        var collapseAllBtn = btnGroup.createEl('button', { text: '全部折叠' });
        collapseAllBtn.style.cssText = 'padding:6px 10px;border:1px solid #ddd;border-radius:4px;cursor:pointer;font-size:12px;background:white;';
        collapseAllBtn.addEventListener('click', function () {
            self.expandedFactions = {};
            self.renderCurrentTab(container.parentElement);
        });

        var addBtn = btnGroup.createEl('button', { text: '+ 添加阵营' });
        addBtn.style.cssText = 'padding:6px 12px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:12px;';
        addBtn.addEventListener('click', function () {
            self.showFactionDialog(null);
        });

        if (this.factions.length === 0) {
            container.createEl('p', { text: '暂无阵营，点击上方按钮添加' }).style.cssText = 'text-align:center;color:#888;padding:20px;';
            return;
        }

        for (var i = 0; i < this.factions.length; i++) {
            (function (faction, index) {
                var isExpanded = self.expandedFactions[faction.name] || false;

                var members = [];
                for (var ci = 0; ci < self.chars.length; ci++) {
                    if (self.getCharField(self.chars[ci], factionField) === faction.name) {
                        members.push(self.chars[ci]);
                    }
                }

                var card = container.createEl('div');
                card.style.cssText = 'margin:6px 0;border:1px solid #e0e0e0;border-radius:6px;background:white;overflow:hidden;';
                if (faction.color) {
                    card.style.borderLeft = '4px solid ' + faction.color;
                }

                var header = card.createEl('div');
                header.style.cssText = 'padding:12px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;background:' + (isExpanded ? '#fafafa' : 'white') + ';';
                if (isExpanded) {
                    header.style.borderBottom = '1px solid #eee';
                }

                var leftSide = header.createEl('div');
                leftSide.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

                var arrow = leftSide.createEl('span', { text: isExpanded ? '▼' : '▶' });
                arrow.style.cssText = 'font-size:10px;color:#888;width:12px;';

                leftSide.createEl('strong', { text: faction.name }).style.cssText = 'font-size:15px;';
                
                if (faction.color) {
                    var dot = leftSide.createEl('span');
                    dot.style.cssText = 'display:inline-block;width:10px;height:10px;border-radius:50%;background:' + faction.color + ';';
                }

                leftSide.createEl('span', { text: members.length + '人' }).style.cssText = 'font-size:12px;color:#888;';

                var rightSide = header.createEl('div');
                rightSide.style.cssText = 'display:flex;gap:4px;';

                var editBtn = rightSide.createEl('button', { text: '编辑' });
                editBtn.style.cssText = 'padding:3px 8px;border:1px solid #ddd;border-radius:3px;cursor:pointer;font-size:11px;background:white;';
                editBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    self.showFactionDialog(faction);
                });

                var delBtn = rightSide.createEl('button', { text: '删除' });
                delBtn.style.cssText = 'padding:3px 8px;border:1px solid #ddd;border-radius:3px;cursor:pointer;font-size:11px;background:white;color:#e74c3c;';
                delBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    if (confirm('确定删除阵营 "' + faction.name + '"？')) {
                        self.factions.splice(index, 1);
                        self.saveFactionsAndRelations();
                        self.renderCurrentTab(container.parentElement);
                    }
                });

                header.addEventListener('click', function () {
                    self.expandedFactions[faction.name] = !isExpanded;
                    self.renderCurrentTab(container.parentElement);
                });

                if (isExpanded) {
                    var body = card.createEl('div');
                    body.style.cssText = 'padding:8px;';

                    if (faction.desc) {
                        body.createEl('div', { text: faction.desc }).style.cssText = 'font-size:12px;color:#666;margin-bottom:8px;font-style:italic;padding:6px;background:#f9f9f9;border-radius:3px;';
                    }

                    if (members.length === 0) {
                        body.createEl('p', { text: '暂无人物属于此阵营' }).style.cssText = 'color:#aaa;font-size:12px;text-align:center;padding:10px;';
                    } else {
                        for (var mi = 0; mi < members.length; mi++) {
                            var m = members[mi];
                            var mRow = body.createEl('div');
                            mRow.style.cssText = 'padding:6px 8px;margin:2px 0;border-bottom:1px solid #f5f5f5;cursor:pointer;font-size:13px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:4px;';

                            var mLeft = mRow.createEl('div');
                            mLeft.createEl('strong', { text: m.name });
                            var mIdentity = self.getCharField(m, '身份');
                            if (mIdentity) {
                                mLeft.createEl('small', { text: ' - ' + mIdentity }).style.cssText = 'color:#888;';
                            }

                            var deathFieldNames = settings.deathFieldNames || '死亡,死亡时间';
                            var mDeath = self.getFieldValue(m, deathFieldNames);
                            if (mDeath) {
                                mRow.createEl('span', { text: '💀 ' + mDeath }).style.cssText = 'font-size:10px;color:#999;background:#f0f0f0;padding:1px 6px;border-radius:8px;';
                            }

                            (function (charData) {
                                mRow.addEventListener('click', function () {
                                    self.showCharDetail(charData);
                                });
                            })(m);
                        }
                    }
                }
            })(this.factions[i], i);
        }
    };

    MyView.prototype.showFactionDialog = function (faction) {
        var self = this;
        var modal = new FactionModal(this.app, faction, function (result) {
            if (faction) {
                var idx = self.factions.indexOf(faction);
                if (idx !== -1) self.factions[idx] = result;
            } else {
                self.factions.push(result);
            }
            self.saveFactionsAndRelations();
            self.render();
        });
        modal.open();
    };

    // ========== 关系视图 ==========
    MyView.prototype.renderRelations = function (container) {
        var self = this;
        
        container.empty();
        container.style.cssText = 'display:flex;flex-direction:column;height:100%;';
        
        var toolbar = container.createEl('div');
        toolbar.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;margin-bottom:15px;padding:10px;background:#f9f9f9;border-radius:8px;align-items:center;flex-shrink:0;';
        
        var titleArea = toolbar.createEl('div');
        titleArea.style.cssText = 'display:flex;align-items:center;gap:10px;';
        titleArea.createEl('strong', { text: '人物关系' }).style.cssText = 'font-size:16px;';
        
        var addBtn = titleArea.createEl('button', { text: '+ 添加关系' });
        addBtn.style.cssText = 'padding:4px 10px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:12px;';
        addBtn.addEventListener('click', function () {
            if (self.chars.length < 2) {
                new obsidian.Notice('至少需要两个人物');
                return;
            }
            self.showRelationDialog(null);
        });
        
        var statsSpan = toolbar.createEl('span', { text: '共 ' + this.relations.length + ' 条关系' });
        statsSpan.style.cssText = 'margin-left:auto;color:#888;font-size:12px;';
        
        var filterBar = container.createEl('div');
        filterBar.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;padding:8px;background:#f5f5f5;border-radius:6px;align-items:center;flex-shrink:0;';
        
        filterBar.createEl('span', { text: '筛选：' }).style.cssText = 'font-size:12px;color:#666;';
        
        var typeSelect = filterBar.createEl('select');
        typeSelect.style.cssText = 'padding:4px 8px;border-radius:4px;border:1px solid #ddd;font-size:12px;';
        typeSelect.add(createOption('all', '📋 全部类型'));
        
        var typeSet = {};
        for (var i = 0; i < this.relations.length; i++) {
            var t = this.relations[i].type || '其他';
            typeSet[t] = true;
        }
        var customTypes = this.plugin.settings.customRelationTypes || '';
        var presetTypes = customTypes ? customTypes.split(',').map(function(s) { return s.trim(); }) : [];
        for (var i = 0; i < presetTypes.length; i++) {
            typeSet[presetTypes[i]] = true;
        }
        var allTypes = Object.keys(typeSet).sort();
        for (var i = 0; i < allTypes.length; i++) {
            typeSelect.add(createOption(allTypes[i], allTypes[i]));
        }
        typeSelect.value = this.relationFilterType;
        typeSelect.addEventListener('change', function() {
            self.relationFilterType = typeSelect.value;
            self.renderRelations(container);
        });
        
        var intimacySelect = filterBar.createEl('select');
        intimacySelect.style.cssText = 'padding:4px 8px;border-radius:4px;border:1px solid #ddd;font-size:12px;';
        intimacySelect.add(createOption('all', '❤️ 全部亲密度'));
        for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
            var lvl = INTIMACY_LEVELS[i];
            intimacySelect.add(createOption(lvl.value.toString(), lvl.label));
        }
        intimacySelect.value = this.relationFilterIntimacy;
        intimacySelect.addEventListener('change', function() {
            self.relationFilterIntimacy = intimacySelect.value;
            self.renderRelations(container);
        });
        
        filterBar.createEl('span', { text: '排序：' }).style.cssText = 'font-size:12px;color:#666;margin-left:8px;';
        
        var sortSelect = filterBar.createEl('select');
        sortSelect.style.cssText = 'padding:4px 8px;border-radius:4px;border:1px solid #ddd;font-size:12px;';
        sortSelect.add(createOption('intimacy', '❤️ 亲密度降序'));
        sortSelect.add(createOption('intimacy_asc', '❤️ 亲密度升序'));
        sortSelect.add(createOption('type', '📌 按类型'));
        sortSelect.add(createOption('name', '👥 按人物名'));
        sortSelect.value = this.relationSortBy;
        sortSelect.addEventListener('change', function() {
            self.relationSortBy = sortSelect.value;
            self.renderRelations(container);
        });
        
        var viewModeBtn = filterBar.createEl('button', { text: this.relationViewMode === 'list' ? '📋 列表视图' : '📁 分组视图' });
        viewModeBtn.style.cssText = 'padding:4px 10px;border-radius:4px;border:1px solid #ddd;background:white;cursor:pointer;font-size:12px;margin-left:auto;';
        viewModeBtn.addEventListener('click', function() {
            self.relationViewMode = self.relationViewMode === 'list' ? 'group' : 'list';
            self.renderRelations(container);
        });
        
        var batchBtn = filterBar.createEl('button', { text: '⚡ 批量操作' });
        batchBtn.style.cssText = 'padding:4px 10px;border-radius:4px;border:1px solid #ddd;background:#e67e22;color:white;cursor:pointer;font-size:12px;';
        batchBtn.addEventListener('click', function() {
            self.showBatchRelationDialog();
        });
        
        var contentArea = container.createEl('div');
        contentArea.className = 'relations-content-area';
        contentArea.style.cssText = 'flex:1;overflow-y:auto;min-height:200px;padding-right:4px;';
        
        var filteredRelations = this.relations.slice();
        if (this.relationFilterType !== 'all') {
            filteredRelations = filteredRelations.filter(function(r) {
                return (r.type || '其他') === self.relationFilterType;
            });
        }
        if (this.relationFilterIntimacy !== 'all') {
            var targetIntimacy = parseInt(this.relationFilterIntimacy);
            filteredRelations = filteredRelations.filter(function(r) {
                return (r.intimacy || 0) === targetIntimacy;
            });
        }
        
        filteredRelations = this.sortRelations(filteredRelations, this.relationSortBy);
        
        if (filteredRelations.length === 0) {
            var emptyMsg = contentArea.createEl('div');
            emptyMsg.style.cssText = 'text-align:center;color:#888;padding:40px;';
            emptyMsg.innerHTML = '📭 暂无关系数据<br><small>点击上方"添加关系"按钮添加</small>';
            this.renderAutoRelationsSuggestions(contentArea);
            return;
        }
        
        if (this.relationViewMode === 'group') {
            this.renderRelationsGrouped(contentArea, filteredRelations);
        } else {
            this.renderRelationsList(contentArea, filteredRelations);
        }
        
        this.renderAutoRelationsSuggestions(contentArea);
    };
    
    MyView.prototype.sortRelations = function(relations, sortBy) {
        var sorted = relations.slice();
        switch(sortBy) {
            case 'intimacy':
                sorted.sort(function(a, b) { return (b.intimacy || 0) - (a.intimacy || 0); });
                break;
            case 'intimacy_asc':
                sorted.sort(function(a, b) { return (a.intimacy || 0) - (b.intimacy || 0); });
                break;
            case 'type':
                sorted.sort(function(a, b) { return (a.type || '').localeCompare(b.type || ''); });
                break;
            case 'name':
                sorted.sort(function(a, b) { 
                    var nameA = a.charA + a.charB;
                    var nameB = b.charA + b.charB;
                    return nameA.localeCompare(nameB);
                });
                break;
            default:
                sorted.sort(function(a, b) { return (b.intimacy || 0) - (a.intimacy || 0); });
        }
        return sorted;
    };
    
    MyView.prototype.renderRelationsList = function(container, relations) {
        var self = this;
        
        for (var i = 0; i < relations.length; i++) {
            (function(rel) {
                var card = container.createEl('div');
                card.style.cssText = 'padding:10px;margin:6px 0;border:1px solid #e0e0e0;border-radius:8px;background:white;';
                card.style.borderLeft = '4px solid ' + getIntimacyColor(rel.intimacy || 0);

                var mainLine = card.createEl('div');
                mainLine.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

                var nameA = mainLine.createEl('strong', { text: rel.charA });
                nameA.style.cssText = 'font-size:14px;cursor:pointer;color:#4a90e2;text-decoration:underline;';
                nameA.addEventListener('click', function() {
                    var cd = self.findChar(rel.charA);
                    if (cd) self.showCharDetail(cd);
                });

                var typeBadge = mainLine.createEl('span', { text: rel.type });
                typeBadge.style.cssText = 'background:#4a90e2;color:white;padding:2px 10px;border-radius:12px;font-size:11px;';

                var intimacyLabel = getIntimacyLabel(rel.intimacy || 0);
                var intimacyColor = getIntimacyColor(rel.intimacy || 0);
                var intimacyBadge = mainLine.createEl('span', { text: '❤️ ' + intimacyLabel });
                intimacyBadge.style.cssText = 'padding:2px 8px;border-radius:10px;font-size:10px;color:white;background:' + intimacyColor + ';';

                var nameB = mainLine.createEl('strong', { text: rel.charB });
                nameB.style.cssText = 'font-size:14px;cursor:pointer;color:#4a90e2;text-decoration:underline;';
                nameB.addEventListener('click', function() {
                    var cd = self.findChar(rel.charB);
                    if (cd) self.showCharDetail(cd);
                });

                if (rel.desc) {
                    card.createEl('div', { text: rel.desc }).style.cssText = 'font-size:12px;color:#666;margin-top:4px;margin-left:4px;';
                }

                if (rel.startTime || rel.endTime) {
                    var timeRange = card.createEl('div');
                    timeRange.style.cssText = 'font-size:10px;color:#888;margin-top:2px;margin-left:4px;';
                    var timeText = '';
                    if (rel.startTime) timeText += '📅 始于 ' + rel.startTime;
                    if (rel.endTime) timeText += (timeText ? ' · ' : '') + '⌛ 止于 ' + rel.endTime;
                    timeRange.textContent = timeText;
                }

                var btnRow = card.createEl('div');
                btnRow.style.cssText = 'display:flex;gap:4px;margin-top:8px;';

                var editRelBtn = btnRow.createEl('button', { text: '编辑' });
                editRelBtn.style.cssText = 'padding:2px 8px;border:1px solid #ddd;border-radius:3px;cursor:pointer;font-size:11px;background:white;';
                editRelBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    self.showRelationDialog(rel);
                });

                var delRelBtn = btnRow.createEl('button', { text: '删除' });
                delRelBtn.style.cssText = 'padding:2px 8px;border:1px solid #ddd;border-radius:3px;cursor:pointer;font-size:11px;background:white;color:#e74c3c;';
                delRelBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    if (confirm('确定删除 ' + rel.charA + ' 与 ' + rel.charB + ' 的「' + rel.type + '」关系？')) {
                        var realIdx = self.relations.indexOf(rel);
                        if (realIdx !== -1) {
                            self.relations.splice(realIdx, 1);
                            self.saveFactionsAndRelations();
                            self.render();
                        }
                    }
                });
            })(relations[i]);
        }
    };
    
    MyView.prototype.renderRelationsGrouped = function(container, relations) {
        var self = this;
        var typeGroups = {};
        for (var i = 0; i < relations.length; i++) {
            var type = relations[i].type || '其他';
            if (!typeGroups[type]) typeGroups[type] = [];
            typeGroups[type].push(relations[i]);
        }
        
        var typeNames = Object.keys(typeGroups).sort();
        for (var ti = 0; ti < typeNames.length; ti++) {
            var type = typeNames[ti];
            var typeRels = typeGroups[type];
            
            var groupHeader = container.createEl('div');
            groupHeader.style.cssText = 'margin-top:15px;margin-bottom:8px;padding:6px 12px;background:#e8f0fe;border-radius:6px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;';
            
            if (this.expandedRelationGroups[type] === undefined) this.expandedRelationGroups[type] = true;
            var arrow = groupHeader.createEl('span', { text: this.expandedRelationGroups[type] ? '▼' : '▶' });
            arrow.style.cssText = 'font-size:10px;color:#888;margin-right:6px;';
            
            groupHeader.createEl('strong', { text: type }).style.cssText = 'font-size:14px;';
            groupHeader.createEl('span', { text: typeRels.length + '条' }).style.cssText = 'font-size:12px;color:#888;';
            
            var sumIntimacy = 0;
            for (var i = 0; i < typeRels.length; i++) {
                sumIntimacy += (typeRels[i].intimacy || 0);
            }
            var avgIntimacy = typeRels.length > 0 ? (sumIntimacy / typeRels.length).toFixed(1) : 0;
            var avgLabel = getIntimacyLabel(Math.round(avgIntimacy));
            groupHeader.createEl('span', { text: '平均: ' + avgLabel }).style.cssText = 'font-size:10px;color:#666;margin-left:8px;';
            
            groupHeader.addEventListener('click', (function(t) {
                return function() {
                    self.expandedRelationGroups[t] = !self.expandedRelationGroups[t];
                    self.render();
                };
            })(type));
            
            if (this.expandedRelationGroups[type]) {
                var groupBody = container.createEl('div');
                groupBody.style.cssText = 'margin-left:16px;margin-bottom:10px;';
                
                var sortedRels = typeRels.slice().sort(function(a, b) {
                    return (b.intimacy || 0) - (a.intimacy || 0);
                });
                
                for (var i = 0; i < sortedRels.length; i++) {
                    var rel = sortedRels[i];
                    var subCard = groupBody.createEl('div');
                    subCard.style.cssText = 'padding:6px 10px;margin:3px 0;border-left:3px solid ' + getIntimacyColor(rel.intimacy || 0) + ';background:#fafafa;border-radius:4px;';
                    
                    var subLine = subCard.createEl('div');
                    subLine.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;';
                    
                    var nameA = subLine.createEl('span', { text: rel.charA });
                    nameA.style.cssText = 'cursor:pointer;color:#4a90e2;text-decoration:underline;font-size:13px;';
                    nameA.addEventListener('click', (function(ca) { 
                        return function() { 
                            var cd = self.findChar(ca); 
                            if (cd) self.showCharDetail(cd); 
                        }; 
                    })(rel.charA));
                    
                    subLine.createEl('span', { text: '→' }).style.cssText = 'color:#999;font-size:11px;';
                    
                    var nameB = subLine.createEl('span', { text: rel.charB });
                    nameB.style.cssText = 'cursor:pointer;color:#4a90e2;text-decoration:underline;font-size:13px;';
                    nameB.addEventListener('click', (function(cb) { 
                        return function() { 
                            var cd = self.findChar(cb); 
                            if (cd) self.showCharDetail(cd); 
                        }; 
                    })(rel.charB));
                    
                    var intimacyLabel = getIntimacyLabel(rel.intimacy || 0);
                    var intimacyColor = getIntimacyColor(rel.intimacy || 0);
                    subLine.createEl('span', { text: '❤️ ' + intimacyLabel }).style.cssText = 'font-size:9px;padding:1px 6px;border-radius:8px;color:white;background:' + intimacyColor + ';';
                    
                    if (rel.desc) {
                        subCard.createEl('div', { text: rel.desc }).style.cssText = 'font-size:11px;color:#888;margin-top:2px;margin-left:4px;';
                    }
                    
                    var editIcon = subCard.createEl('span', { text: '✏️' });
                    editIcon.style.cssText = 'float:right;cursor:pointer;opacity:0.5;font-size:11px;';
                    editIcon.addEventListener('click', function(e) {
                        e.stopPropagation();
                        self.showRelationDialog(rel);
                    });
                }
            }
        }
    };
    
    MyView.prototype.renderAutoRelationsSuggestions = function(container) {
        var self = this;
        var autoRels = this.buildAutoRelations();
        var manualKeys = {};
        for (var i = 0; i < this.relations.length; i++) {
            var key = [this.relations[i].charA, this.relations[i].charB].sort().join('|||');
            manualKeys[key] = true;
        }
        
        var newAutoRels = [];
        var autoKeys = Object.keys(autoRels);
        for (var i = 0; i < autoKeys.length; i++) {
            if (!manualKeys[autoKeys[i]]) {
                newAutoRels.push(autoRels[autoKeys[i]]);
            }
        }
        
        if (newAutoRels.length > 0) {
            var suggestDiv = container.createEl('div');
            suggestDiv.style.cssText = 'margin-top:20px;border-top:2px solid #e0e0e0;padding-top:12px;';
            suggestDiv.createEl('div', { text: '💡 建议添加的关系（基于共同出场次数）' }).style.cssText = 'font-size:12px;color:#888;margin-bottom:8px;';
            
            newAutoRels.sort(function(a, b) { return b.count - a.count; });
            var showCount = Math.min(10, newAutoRels.length);
            
            for (var i = 0; i < showCount; i++) {
                var rel = newAutoRels[i];
                var card = suggestDiv.createEl('div');
                card.style.cssText = 'padding:6px 10px;margin:4px 0;border:1px dashed #ddd;border-radius:6px;background:#fafafa;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;';
                card.innerHTML = '<div><strong>' + rel.charA + '</strong> <span style="color:#888;">↔</span> <strong>' + rel.charB + '</strong><br><small style="color:#888;">共同出现 ' + rel.count + ' 次</small></div>';
                var addBtn = card.createEl('button', { text: '+ 添加关系' });
                addBtn.style.cssText = 'padding:2px 10px;border:1px solid #4a90e2;border-radius:3px;cursor:pointer;font-size:11px;background:white;color:#4a90e2;';
                addBtn.addEventListener('click', (function(rd) {
                    return function(e) {
                        e.stopPropagation();
                        self.showRelationDialog({
                            charA: rd.charA,
                            charB: rd.charB,
                            type: '同期出场',
                            desc: '自动检测：共同出现 ' + rd.count + ' 次',
                            intimacy: 1
                        });
                    };
                })(rel));
            }
            
            if (newAutoRels.length > 10) {
                suggestDiv.createEl('div', { text: '...还有 ' + (newAutoRels.length - 10) + ' 条建议' }).style.cssText = 'font-size:11px;color:#aaa;text-align:center;padding:4px;';
            }
            
            var addAllBtn = suggestDiv.createEl('button', { text: '📌 一键添加所有建议关系' });
            addAllBtn.style.cssText = 'margin-top:8px;padding:4px 12px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;font-size:11px;width:100%;';
            addAllBtn.addEventListener('click', function() {
                var addedCount = 0;
                for (var i = 0; i < newAutoRels.length; i++) {
                    var rel = newAutoRels[i];
                    var exists = false;
                    for (var j = 0; j < self.relations.length; j++) {
                        if ((self.relations[j].charA === rel.charA && self.relations[j].charB === rel.charB) ||
                            (self.relations[j].charA === rel.charB && self.relations[j].charB === rel.charA)) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        self.relations.push({
                            charA: rel.charA,
                            charB: rel.charB,
                            type: '同期出场',
                            desc: '自动检测：共同出现 ' + rel.count + ' 次',
                            intimacy: 1
                        });
                        addedCount++;
                    }
                }
                self.saveFactionsAndRelations();
                self.render();
                new obsidian.Notice('已添加 ' + addedCount + ' 条关系');
            });
        }
    };
    
    MyView.prototype.showBatchRelationDialog = function() {
        var self = this;
        var modal = new BatchRelationModal(this.app, this.relations, this.chars, function(result) {
            if (result.action === 'batch_delete_by_type') {
                var toDelete = [];
                for (var i = 0; i < self.relations.length; i++) {
                    if ((self.relations[i].type || '其他') === result.type) {
                        toDelete.push(self.relations[i]);
                    }
                }
                for (var i = 0; i < toDelete.length; i++) {
                    var idx = self.relations.indexOf(toDelete[i]);
                    if (idx !== -1) self.relations.splice(idx, 1);
                }
                self.saveFactionsAndRelations();
                self.render();
                new obsidian.Notice('已删除 ' + toDelete.length + ' 条「' + result.type + '」关系');
            } else if (result.action === 'batch_update_intimacy') {
                var updatedCount = 0;
                for (var i = 0; i < self.relations.length; i++) {
                    if ((self.relations[i].type || '其他') === result.type) {
                        self.relations[i].intimacy = result.newIntimacy;
                        updatedCount++;
                    }
                }
                self.saveFactionsAndRelations();
                self.render();
                new obsidian.Notice('已更新 ' + updatedCount + ' 条关系的亲密度');
            } else if (result.action === 'clear_all') {
                if (confirm('⚠️ 确定删除所有关系吗？此操作不可撤销！')) {
                    self.relations = [];
                    self.saveFactionsAndRelations();
                    self.render();
                    new obsidian.Notice('已清空所有关系');
                }
            } else if (result.action === 'export_relations') {
                var csvRows = [['人物A', '人物B', '关系类型', '亲密度', '开始时间', '结束时间', '描述']];
                for (var i = 0; i < self.relations.length; i++) {
                    var r = self.relations[i];
                    csvRows.push([r.charA, r.charB, r.type, r.intimacy || 0, r.startTime || '', r.endTime || '', r.desc || '']);
                }
                var csvContent = csvRows.map(function(row) {
                    return row.map(function(cell) {
                        return '"' + String(cell).replace(/"/g, '""') + '"';
                    }).join(',');
                }).join('\n');
                var blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = 'relations-export.csv';
                a.click();
                URL.revokeObjectURL(url);
                new obsidian.Notice('导出成功');
            }
        });
        modal.open();
    };

    MyView.prototype.findChar = function (name) {
        return this.charMap[name] || null;
    };

    MyView.prototype.buildAutoRelations = function () {
        var relations = {};
        for (var i = 0; i < this.timeline.length; i++) {
            var appeared = findCharsInEvent(this.timeline[i].event, this.charNames);
            for (var a = 0; a < appeared.length; a++) {
                for (var b = a + 1; b < appeared.length; b++) {
                    var key = [appeared[a], appeared[b]].sort().join('|||');
                    if (!relations[key]) {
                        relations[key] = { charA: appeared[a], charB: appeared[b], count: 0 };
                    }
                    relations[key].count++;
                }
            }
        }
        return relations;
    };

    MyView.prototype.showRelationDialog = function (prefill) {
        var self = this;
        var customTypes = this.plugin.settings.customRelationTypes || '';
        var relTypes = customTypes ? customTypes.split(',').map(function(s) { return s.trim(); }) : 
            ['父子', '母子', '父女', '母女', '兄弟', '姐妹', '兄妹', '姐弟', '夫妻', '恋人', '朋友', '挚友', '战友', '师生', '师徒', '君臣', '主仆', '敌人', '对手', '仇人', '同事', '同盟', '同期出场', '其他'];
        
        var modal = new RelationModal(this.app, this.chars, prefill, relTypes, function (result) {
            if (prefill && prefill.charA !== undefined) {
                var idx = self.relations.findIndex(function (r) {
                    return r.charA === prefill.charA && r.charB === prefill.charB && r.type === prefill.type;
                });
                if (idx !== -1) {
                    self.relations[idx] = result;
                } else {
                    self.relations.push(result);
                }
            } else {
                self.relations.push(result);
            }
            self.saveFactionsAndRelations();
            self.render();
        });
        modal.open();
    };

    // ========== 时间线视图 ==========
    MyView.prototype.renderTimeline = function (container) {
        var self = this;
        container.empty();
        container.style.cssText = 'padding:10px;overflow-y:auto;';

        var tagToolbar = container.createEl('div');
        tagToolbar.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;padding:10px;background:#f5f5f5;border-radius:6px;align-items:center;flex-shrink:0;';

        tagToolbar.createEl('span', { text: '🏷️ 标签管理：' }).style.cssText = 'font-weight:bold;font-size:13px;color:#555;';

        var tagManageBtn = tagToolbar.createEl('button', { text: '✏️ 管理标签' });
        tagManageBtn.style.cssText = 'padding:4px 12px;background:#9b59b6;color:white;border:none;border-radius:4px;cursor:pointer;font-size:12px;';
        tagManageBtn.addEventListener('click', function() {
            var modal = new EventTagModal(self.plugin.app, self.plugin, function() {
                self.loadAllData().then(function() {
                    self.renderTimeline(container);
                });
            });
            modal.open();
        });

        var currentTags = getEventTags(this.plugin);
        if (currentTags.length > 0) {
            var tagDisplay = tagToolbar.createEl('div');
            tagDisplay.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;margin-left:8px;';
            for (var i = 0; i < currentTags.length; i++) {
                var tag = currentTags[i];
                var chip = tagDisplay.createEl('span', { text: tag.label });
                chip.style.cssText = 'padding:2px 8px;border-radius:12px;font-size:11px;color:white;background:' + tag.color + ';';
            }
        }

        var filterBar = container.createEl('div');
        filterBar.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;margin-bottom:15px;padding:8px;background:#f9f9f9;border-radius:6px;flex-shrink:0;';

        var allBtn = filterBar.createEl('button', { text: '全部' });
        allBtn.style.cssText = 'padding:4px 12px;border-radius:16px;border:1px solid #ddd;cursor:pointer;background:' + (this.selectedTag === '' ? '#4a90e2' : 'white') + ';color:' + (this.selectedTag === '' ? 'white' : '#333') + ';';
        allBtn.addEventListener('click', function() {
            self.selectedTag = '';
            self.renderTimeline(container);
        });

        for (var i = 0; i < currentTags.length; i++) {
            (function(tag) {
                var btn = filterBar.createEl('button', { text: tag.label });
                btn.style.cssText = 'padding:4px 12px;border-radius:16px;border:1px solid #ddd;cursor:pointer;background:' + (self.selectedTag === tag.value ? tag.color : 'white') + ';color:' + (self.selectedTag === tag.value ? 'white' : '#333') + ';';
                btn.addEventListener('click', function() {
                    self.selectedTag = tag.value;
                    self.renderTimeline(container);
                });
            })(currentTags[i]);
        }

        var filteredTimeline = this.timeline;
        if (this.selectedTag) {
            filteredTimeline = this.timeline.filter(function(e) {
                return e.tag === self.selectedTag;
            });
        }

        if (filteredTimeline.length === 0) {
            container.createEl('p', { text: '暂无时间线事件' }).style.cssText = 'text-align:center;color:#888;padding:40px;';
            return;
        }

        var yearGroups = {};
        for (var i = 0; i < filteredTimeline.length; i++) {
            var y = filteredTimeline[i].year;
            if (!yearGroups[y]) yearGroups[y] = [];
            yearGroups[y].push(filteredTimeline[i]);
        }

        var years = Object.keys(yearGroups).sort().reverse();

        for (var yi = 0; yi < years.length; yi++) {
            var year = years[yi];
            var records = yearGroups[year];
            var yearNode = container.createEl('div');
            yearNode.style.cssText = 'margin-bottom:15px;';

            yearNode.createEl('h3', { text: year })
                .style.cssText = 'margin:0 0 8px;padding:4px 10px;background:#f0f4ff;border-radius:4px;display:inline-block;font-size:15px;';

            var monthGroups = {};
            for (var i = 0; i < records.length; i++) {
                var m = records[i].month || '未标注';
                if (!monthGroups[m]) monthGroups[m] = [];
                monthGroups[m].push(records[i]);
            }

            var months = Object.keys(monthGroups);
            for (var mi = 0; mi < months.length; mi++) {
                var month = months[mi];
                var events = monthGroups[month];
                var monthNode = yearNode.createEl('div');
                monthNode.style.cssText = 'margin-left:16px;margin-bottom:8px;';

                monthNode.createEl('div', { text: month })
                    .style.cssText = 'font-size:13px;color:#666;margin-bottom:4px;font-weight:bold;';

                for (var ei = 0; ei < events.length; ei++) {
                    var eventDiv = monthNode.createEl('div');
                    var tagColor = events[ei].tag ? getTagColor(self.plugin, events[ei].tag) : '#4a90e2';
                    eventDiv.style.cssText = 'padding:4px 8px;margin:2px 0;border-left:2px solid ' + tagColor + ';font-size:13px;line-height:1.6;';

                    if (events[ei].tag) {
                        var tagSpan = eventDiv.createEl('span', { text: getTagLabel(self.plugin, events[ei].tag) });
                        tagSpan.style.cssText = 'background:' + tagColor + ';color:white;padding:0px 6px;border-radius:10px;font-size:10px;margin-right:6px;';
                    }

                    var eventText = events[ei].event;
                    for (var ci = 0; ci < this.chars.length; ci++) {
                        var cn = this.chars[ci].name;
                        if (eventText.indexOf(cn) !== -1) {
                            eventText = eventText.split(cn).join(
                                '<span class="clink" data-name="' + cn + '" style="color:#4a90e2;cursor:pointer;font-weight:bold;text-decoration:underline;">' + cn + '</span>'
                            );
                        }
                    }
                    eventDiv.innerHTML += eventText;
                }
            }
        }

        var links = container.querySelectorAll('.clink');
        for (var i = 0; i < links.length; i++) {
            (function (link) {
                link.addEventListener('click', function () {
                    var name = link.getAttribute('data-name');
                    var charData = null;
                    for (var j = 0; j < self.chars.length; j++) {
                        if (self.chars[j].name === name) { charData = self.chars[j]; break; }
                    }
                    if (charData) self.showCharDetail(charData);
                });
            })(links[i]);
        }
    };

    // ========== 生命周期视图 ==========
    MyView.prototype.renderLifecycle = function (container) {
        var self = this;
        container.empty();
        container.style.cssText = 'padding:10px;overflow-y:auto;';

        container.createEl('h3', { text: '⏳ 人物生命周期' }).style.cssText = 'margin:0 0 8px;';
        container.createEl('p', {
            text: '支持公元前/公元时间排序。出生、首次出场、死亡字段可在设置中配置。时间格式示例：公元前280年、前100年、280年、公元100年'
        }).style.cssText = 'font-size:11px;color:var(--text-muted);margin:0 0 12px;';

        var toolbar = container.createEl('div', { cls: 'my-char-lifecycle-toolbar' });
        toolbar.createEl('span', { text: '排序依据：' }).style.fontSize = '12px';

        var sortSelect = toolbar.createEl('select');
        sortSelect.add(createOption('birth', '出生时间'));
        sortSelect.add(createOption('firstAppear', '首次出场'));
        sortSelect.add(createOption('death', '死亡时间'));
        sortSelect.value = this.lifecycleSortBy;
        sortSelect.addEventListener('change', function() {
            self.lifecycleSortBy = sortSelect.value;
            self.renderLifecycle(container);
        });

        var orderSelect = toolbar.createEl('select');
        orderSelect.add(createOption('asc', '从早到晚 ↑'));
        orderSelect.add(createOption('desc', '从晚到早 ↓'));
        orderSelect.value = this.lifecycleSortOrder;
        orderSelect.addEventListener('change', function() {
            self.lifecycleSortOrder = orderSelect.value;
            self.renderLifecycle(container);
        });

        var onlyDatedBtn = toolbar.createEl('button', {
            text: this.lifecycleOnlyDated ? '✓ 仅显示有时间数据' : '显示全部人物',
            cls: 'my-char-view-btn'
        });
        onlyDatedBtn.style.fontSize = '12px';
        onlyDatedBtn.addEventListener('click', function() {
            self.lifecycleOnlyDated = !self.lifecycleOnlyDated;
            self.renderLifecycle(container);
        });

        var legend = container.createEl('div', { cls: 'my-char-lifecycle-legend' });
        var legendItems = [
            { cls: 'my-char-lifecycle-marker-birth', label: '出生' },
            { cls: 'my-char-lifecycle-marker-appear', label: '首次出场' },
            { cls: 'my-char-lifecycle-marker-death', label: '死亡' }
        ];
        for (var li = 0; li < legendItems.length; li++) {
            var legItem = legend.createEl('span', { cls: 'my-char-lifecycle-legend-item' });
            var dot = legItem.createEl('span', { cls: 'my-char-lifecycle-legend-dot ' + legendItems[li].cls });
            legItem.createEl('span', { text: legendItems[li].label });
        }

        var items = [];
        var globalMin = Infinity;
        var globalMax = -Infinity;

        for (var ci = 0; ci < this.chars.length; ci++) {
            var char = this.chars[ci];
            var lc = getCharLifecycle(this, char);
            var points = [];
            if (lc.birthParsed && lc.birthParsed.sortValue !== null) points.push(lc.birthParsed.sortValue);
            if (lc.firstAppearParsed && lc.firstAppearParsed.sortValue !== null) points.push(lc.firstAppearParsed.sortValue);
            if (lc.deathParsed && lc.deathParsed.sortValue !== null) points.push(lc.deathParsed.sortValue);

            if (this.lifecycleOnlyDated && points.length === 0) continue;

            var sortKey = null;
            if (this.lifecycleSortBy === 'birth' && lc.birthParsed) sortKey = lc.birthParsed.sortValue;
            else if (this.lifecycleSortBy === 'firstAppear' && lc.firstAppearParsed) sortKey = lc.firstAppearParsed.sortValue;
            else if (this.lifecycleSortBy === 'death' && lc.deathParsed) sortKey = lc.deathParsed.sortValue;
            if (sortKey === null && points.length > 0) sortKey = points[0];
            if (sortKey === null) sortKey = this.lifecycleSortOrder === 'asc' ? Infinity : -Infinity;

            if (points.length > 0) {
                var rowMin = Math.min.apply(null, points);
                var rowMax = Math.max.apply(null, points);
                globalMin = Math.min(globalMin, rowMin);
                globalMax = Math.max(globalMax, rowMax);
            }

            items.push({ char: char, lifecycle: lc, sortKey: sortKey, points: points });
        }

        items.sort(function(a, b) {
            if (a.sortKey === b.sortKey) return a.char.name.localeCompare(b.char.name);
            return self.lifecycleSortOrder === 'asc' ? a.sortKey - b.sortKey : b.sortKey - a.sortKey;
        });

        if (items.length === 0) {
            container.createEl('p', { text: '暂无可用的时间数据，请在人物文件中填写出生/首次出场/死亡字段', cls: 'my-char-view-empty' });
            return;
        }

        if (!isFinite(globalMin) || !isFinite(globalMax)) {
            globalMin = -100;
            globalMax = 100;
        }
        if (globalMin === globalMax) {
            globalMin -= 10;
            globalMax += 10;
        }

        var range = globalMax - globalMin;
        var axis = container.createEl('div', { cls: 'my-char-lifecycle-axis' });
        var axisMarks = [globalMin, globalMin + range * 0.5, globalMax];
        for (var am = 0; am < axisMarks.length; am++) {
            var mark = axis.createEl('span', { cls: 'my-char-lifecycle-axis-label', text: formatSortValue(axisMarks[am]) });
            mark.style.left = ((axisMarks[am] - globalMin) / range * 100) + '%';
        }

        var list = container.createEl('div');
        for (var ii = 0; ii < items.length; ii++) {
            (function(entry) {
                var lc = entry.lifecycle;
                var row = list.createEl('div', { cls: 'my-char-lifecycle-row' });

                var nameEl = row.createEl('div', { text: entry.char.name, cls: 'my-char-lifecycle-name' });
                nameEl.setAttr('title', entry.char.name);
                nameEl.addEventListener('click', function() {
                    self.showCharDetail(entry.char);
                });

                var track = row.createEl('div', { cls: 'my-char-lifecycle-track' });

                if (entry.points.length > 0) {
                    var rowMinVal = Math.min.apply(null, entry.points);
                    var rowMaxVal = Math.max.apply(null, entry.points);
                    var leftPct = ((rowMinVal - globalMin) / range) * 100;
                    var widthPct = Math.max(((rowMaxVal - rowMinVal) / range) * 100, 0.5);

                    var span = track.createEl('div', { cls: 'my-char-lifecycle-span my-char-lifecycle-span-life' });
                    span.style.left = leftPct + '%';
                    span.style.width = widthPct + '%';
                    span.setAttr('title', '活跃区间');

                    function placeMarker(parsed, cls, tip) {
                        if (!parsed || parsed.sortValue === null) return;
                        var m = track.createEl('div', { cls: 'my-char-lifecycle-marker ' + cls });
                        m.style.left = ((parsed.sortValue - globalMin) / range * 100) + '%';
                        m.setAttr('title', tip + ': ' + parsed.display);
                    }
                    placeMarker(lc.birthParsed, 'my-char-lifecycle-marker-birth', '出生');
                    placeMarker(lc.firstAppearParsed, 'my-char-lifecycle-marker-appear', '首次出场');
                    placeMarker(lc.deathParsed, 'my-char-lifecycle-marker-death', '死亡');
                } else {
                    track.createEl('span', { text: '无时间数据' }).style.cssText = 'font-size:11px;color:var(--text-muted);padding:4px 8px;';
                }

                var labels = row.createEl('div', { cls: 'my-char-lifecycle-labels' });
                if (lc.birth) labels.createEl('div', { text: '🟢 ' + lc.birth });
                if (lc.firstAppear) labels.createEl('div', { text: '🔵 ' + lc.firstAppear });
                if (lc.death) labels.createEl('div', { text: '🔴 ' + lc.death });
                if (!lc.birth && !lc.firstAppear && !lc.death) labels.createEl('div', { text: '—' });
            })(items[ii]);
        }
    };

    // ========== 统计视图 ==========
    MyView.prototype.renderStatistics = function (container) {
        var self = this;
        container.empty();
        container.style.cssText = 'padding:10px;overflow-y:auto;';

        container.createEl('h3', { text: '📊 数据统计' }).style.cssText = 'margin:0 0 15px;';

        var statsGrid = container.createEl('div');
        statsGrid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:20px;';

        var totalChars = this.chars.length;
        var totalEvents = this.timeline.length;
        var totalRels = this.relations.length;
        var totalFactions = this.factions.length;

        var cards = [
            { label: '人物', value: totalChars, icon: '👥', color: '#4a90e2' },
            { label: '事件', value: totalEvents, icon: '📅', color: '#2ecc71' },
            { label: '关系', value: totalRels, icon: '🔗', color: '#e74c3c' },
            { label: '阵营', value: totalFactions, icon: '🏰', color: '#9b59b6' }
        ];

        for (var i = 0; i < cards.length; i++) {
            var card = statsGrid.createEl('div');
            card.style.cssText = 'background:white;border-radius:8px;padding:12px;text-align:center;border:1px solid #e0e0e0;';
            card.innerHTML = '<div style="font-size:24px;">' + cards[i].icon + '</div>' +
                '<div style="font-size:22px;font-weight:bold;color:' + cards[i].color + ';">' + cards[i].value + '</div>' +
                '<div style="font-size:11px;color:#888;">' + cards[i].label + '</div>';
        }

        if (this.relations.length > 0) {
            container.createEl('h4', { text: '❤️ 亲密度分布' }).style.cssText = 'margin:15px 0 8px;font-size:14px;';
            var intimacyCounts = {};
            for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
                intimacyCounts[INTIMACY_LEVELS[i].value] = 0;
            }
            for (var i = 0; i < this.relations.length; i++) {
                var val = this.relations[i].intimacy || 0;
                intimacyCounts[val] = (intimacyCounts[val] || 0) + 1;
            }
            
            var intimacyChart = container.createEl('div');
            intimacyChart.style.cssText = 'background:#f9f9f9;border-radius:6px;padding:12px;margin-bottom:15px;';
            
            for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
                var lvl = INTIMACY_LEVELS[i];
                var cnt = intimacyCounts[lvl.value] || 0;
                if (cnt === 0 && this.relations.length === 0) continue;
                var percent = (cnt / (this.relations.length || 1)) * 100;
                var row = intimacyChart.createEl('div');
                row.style.cssText = 'margin:5px 0;display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
                row.createEl('span', { text: lvl.label }).style.cssText = 'width:60px;font-size:11px;color:' + lvl.color + ';font-weight:bold;';
                var bar = row.createEl('div');
                bar.style.cssText = 'height:16px;background:' + lvl.color + ';border-radius:8px;width:' + percent + '%;max-width:150px;';
                row.createEl('span', { text: cnt + '个' }).style.cssText = 'font-size:11px;color:#666;';
            }
        }

        container.createEl('h4', { text: '🏷️ 事件标签分布' }).style.cssText = 'margin:15px 0 8px;font-size:14px;';
        var tagCounts = {};
        for (var i = 0; i < this.timeline.length; i++) {
            var tag = this.timeline[i].tag || '其他';
            tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        }
        
        var tagContainer = container.createEl('div');
        tagContainer.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;margin-bottom:15px;';
        
        var sortedTags = Object.keys(tagCounts).sort(function(a,b) {
            return tagCounts[b] - tagCounts[a];
        });
        
        for (var i = 0; i < sortedTags.length; i++) {
            var tag = sortedTags[i];
            var cnt = tagCounts[tag];
            var percent = totalEvents > 0 ? Math.round((cnt / totalEvents) * 100) : 0;
            var tagChip = tagContainer.createEl('div');
            var tagColor = getTagColor(this.plugin, tag);
            tagChip.style.cssText = 'padding:6px 12px;border-radius:20px;font-size:12px;color:white;background:' + tagColor + ';display:flex;align-items:center;gap:6px;';
            tagChip.innerHTML = getTagLabel(this.plugin, tag) + ' <strong style="font-size:14px;">' + cnt + '</strong> <span style="font-size:10px;opacity:0.8;">(' + percent + '%)</span>';
        }

        container.createEl('h4', { text: '🏆 出场排行榜' }).style.cssText = 'margin:15px 0 8px;font-size:14px;';
        var sortedAppear = Object.keys(this.appearCounts).map(function(k) {
            return { name: k, count: self.appearCounts[k] || 0 };
        }).filter(function(c) { return c.count > 0; }).sort(function(a, b) { return b.count - a.count; }).slice(0, 10);

        var rankList = container.createEl('div', { cls: 'my-char-view-panel' });
        
        var medals = ['🥇', '🥈', '🥉'];
        for (var i = 0; i < sortedAppear.length; i++) {
            var row = rankList.createEl('div');
            row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:6px 8px;border-bottom:1px solid #eee;';
            var medal = i < 3 ? medals[i] : (i + 1) + '.';
            var nameSpan = row.createEl('span');
            nameSpan.createEl('span', { text: medal + ' ' });
            var nameLink = nameSpan.createEl('strong', { text: sortedAppear[i].name, cls: 'my-char-view-link' });
            nameLink.addEventListener('click', (function(charName) {
                return function() {
                    var cd = self.findChar(charName);
                    if (cd) self.showCharDetail(cd);
                };
            })(sortedAppear[i].name));
            var countBadge = row.createEl('span', { text: sortedAppear[i].count + '次', cls: 'my-char-view-btn' });
            countBadge.style.fontSize = '11px';
            countBadge.style.padding = '2px 8px';
        }

        container.createEl('h4', { text: '📈 年份事件趋势' }).style.cssText = 'margin:15px 0 8px;font-size:14px;';
        var yearCounts = {};
        for (var i = 0; i < this.timeline.length; i++) {
            var y = this.timeline[i].year;
            yearCounts[y] = (yearCounts[y] || 0) + 1;
        }
        var years = Object.keys(yearCounts).sort();
        var maxCount = 1;
        for (var y in yearCounts) {
            if (yearCounts[y] > maxCount) maxCount = yearCounts[y];
        }

        var chartDiv = container.createEl('div');
        chartDiv.style.cssText = 'background:#f9f9f9;border-radius:6px;padding:12px;overflow-x:auto;';
        var chartInner = chartDiv.createEl('div');
        chartInner.style.cssText = 'min-width:300px;';
        
        for (var i = 0; i < years.length; i++) {
            var y = years[i];
            var cnt = yearCounts[y];
            var barWidth = (cnt / maxCount) * 100;
            var row = chartInner.createEl('div');
            row.style.cssText = 'margin:6px 0;display:flex;align-items:center;gap:8px;';
            row.createEl('span', { text: y }).style.cssText = 'width:70px;font-size:12px;font-weight:bold;';
            var bar = row.createEl('div');
            bar.style.cssText = 'height:22px;background:linear-gradient(90deg,var(--interactive-accent),#6c5ce7);border-radius:4px;';
            bar.style.width = Math.max(barWidth, 4) + '%';
            row.createEl('span', { text: cnt + '件' }).style.cssText = 'font-size:11px;color:#666;min-width:40px;';
        }

        var reportBtn = container.createEl('button', { text: '📄 导出统计报告 (Markdown)' });
        reportBtn.style.cssText = 'margin-top:20px;padding:8px 16px;background:#9b59b6;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
        reportBtn.addEventListener('click', function() {
            var report = '# 关系谱统计报告\n\n';
            report += '> 生成时间：' + new Date().toLocaleString() + '\n\n';
            report += '## 数据概览\n\n';
            report += '| 类别 | 数量 |\n|------|------|\n';
            report += '| 人物 | ' + totalChars + ' |\n';
            report += '| 事件 | ' + totalEvents + ' |\n';
            report += '| 关系 | ' + totalRels + ' |\n';
            report += '| 阵营 | ' + totalFactions + ' |\n\n';
            
            report += '## 出场排行榜\n\n';
            for (var i = 0; i < sortedAppear.length; i++) {
                report += (i+1) + '. **' + sortedAppear[i].name + '** - ' + sortedAppear[i].count + '次\n';
            }
            
            report += '\n## 事件标签分布\n\n';
            for (var tag in tagCounts) {
                report += '- ' + getTagLabel(self.plugin, tag) + ': ' + tagCounts[tag] + '件\n';
            }

            if (this.relations.length > 0) {
                report += '\n## 亲密度分布\n\n';
                for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
                    var lvl = INTIMACY_LEVELS[i];
                    var cnt = intimacyCounts[lvl.value] || 0;
                    if (cnt > 0) {
                        report += '- ' + lvl.label + ': ' + cnt + '个关系\n';
                    }
                }
            }
            
            var blob = new Blob([report], { type: 'text/markdown' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'statistics-report.md';
            a.click();
            URL.revokeObjectURL(url);
            new obsidian.Notice('报告已导出');
        });
    };

    // ========== 导入导出视图 ==========
    MyView.prototype.renderImportExport = function (container) {
        var self = this;
        container.empty();
        container.style.cssText = 'padding:10px;overflow-y:auto;';

        container.createEl('h3', { text: '💾 数据导入/导出' }).style.cssText = 'margin:0 0 15px;';

        var exportDiv = container.createEl('div');
        exportDiv.style.cssText = 'background:#f9f9f9;border-radius:8px;padding:15px;margin-bottom:20px;';

        exportDiv.createEl('h4', { text: '导出数据' }).style.cssText = 'margin:0 0 10px;font-size:14px;';

        var exportData = {
            version: '1.2.0',
            exportTime: new Date().toISOString(),
            factions: this.factions,
            relations: this.relations,
            chars: this.chars.map(function(c) {
                return { name: c.name, fields: c.fields };
            }),
            timeline: this.timeline
        };

        var exportJSONBtn = exportDiv.createEl('button', { text: '📄 导出为 JSON' });
        exportJSONBtn.style.cssText = 'padding:8px 16px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;margin-right:10px;';
        exportJSONBtn.addEventListener('click', function() {
            exportToJSON(exportData, 'char-relation-data.json');
            new obsidian.Notice('导出成功');
        });

        var exportCSVBtn = exportDiv.createEl('button', { text: '📊 导出关系为 CSV' });
        exportCSVBtn.style.cssText = 'padding:8px 16px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;';
        exportCSVBtn.addEventListener('click', function() {
            var csvRows = [['人物A', '人物B', '关系类型', '亲密度', '开始时间', '结束时间', '描述']];
            for (var i = 0; i < self.relations.length; i++) {
                var r = self.relations[i];
                csvRows.push([r.charA, r.charB, r.type, r.intimacy || 0, r.startTime || '', r.endTime || '', r.desc || '']);
            }
            var csvContent = csvRows.map(function(row) {
                return row.map(function(cell) {
                    return '"' + String(cell).replace(/"/g, '""') + '"';
                }).join(',');
            }).join('\n');
            var blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'relations.csv';
            a.click();
            URL.revokeObjectURL(url);
            new obsidian.Notice('导出成功');
        });

        var importDiv = container.createEl('div');
        importDiv.style.cssText = 'background:#f9f9f9;border-radius:8px;padding:15px;';

        importDiv.createEl('h4', { text: '导入数据' }).style.cssText = 'margin:0 0 10px;font-size:14px;';

        var fileInput = importDiv.createEl('input', { type: 'file', accept: '.json' });
        fileInput.style.cssText = 'margin-bottom:10px;';

        var importBtn = importDiv.createEl('button', { text: '📂 导入 JSON 文件' });
        importBtn.style.cssText = 'padding:8px 16px;background:#e67e22;color:white;border:none;border-radius:4px;cursor:pointer;';
        importBtn.addEventListener('click', function() {
            if (!fileInput.files || fileInput.files.length === 0) {
                new obsidian.Notice('请选择文件');
                return;
            }
            importFromJSON(fileInput.files[0], function(data) {
                var validation = validateImportData(data);
                if (!validation.ok) {
                    new obsidian.Notice('导入失败：' + validation.error);
                    return;
                }
                if (data.factions) self.factions = data.factions;
                if (data.relations) self.relations = data.relations;
                self.saveFactionsAndRelations().then(function() {
                    return self.loadAllData();
                }).then(function() {
                    new obsidian.Notice('导入成功');
                    self.render();
                });
            });
        });

        var warning = importDiv.createEl('p', { text: '⚠️ 注意：导入会覆盖现有的阵营和关系数据（人物和时间线不会被覆盖）' });
        warning.style.cssText = 'color:#e67e22;font-size:11px;margin-top:10px;';
    };

    // ========== 人物详情弹窗 ==========
    MyView.prototype.showCharDetail = function (charData) {
        var self = this;
        var relatedEvents = [];
        for (var i = 0; i < this.timeline.length; i++) {
            var appeared = findCharsInEvent(this.timeline[i].event, this.charNames);
            if (appeared.indexOf(charData.name) !== -1) {
                relatedEvents.push(this.timeline[i]);
            }
        }

        var relatedChars = {};
        for (var ei = 0; ei < relatedEvents.length; ei++) {
            var othersInEvent = findCharsInEvent(relatedEvents[ei].event, this.charNames);
            for (var oi = 0; oi < othersInEvent.length; oi++) {
                var other = othersInEvent[oi];
                if (other !== charData.name) {
                    if (!relatedChars[other]) relatedChars[other] = [];
                    if (relatedChars[other].indexOf(relatedEvents[ei]) === -1) {
                        relatedChars[other].push(relatedEvents[ei]);
                    }
                }
            }
        }

        var manualRels = [];
        for (var i = 0; i < this.relations.length; i++) {
            if (this.relations[i].charA === charData.name || this.relations[i].charB === charData.name) {
                manualRels.push(this.relations[i]);
            }
        }

        new DetailModal(this.app, charData, relatedEvents, relatedChars, manualRels, this).open();
    };

    return MyView;
}(obsidian.ItemView));

// ========== 阵营编辑弹窗 ==========
var FactionModal = /** @class */ (function (_super) {
    __extends(FactionModal, _super);
    function FactionModal(app, faction, onSubmit) {
        var _this = _super.call(this, app) || this;
        _this.faction = faction;
        _this.onSubmit = onSubmit;
        return _this;
    }

    FactionModal.prototype.onOpen = function () {
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;';

        el.createEl('h3', { text: this.faction ? '编辑阵营' : '添加阵营' });

        var nameValue = this.faction ? this.faction.name : '';
        var colorValue = this.faction ? this.faction.color || '#4a90e2' : '#4a90e2';
        var descValue = this.faction ? this.faction.desc || '' : '';

        var nameRow = el.createEl('div');
        nameRow.style.cssText = 'margin:10px 0;';
        nameRow.createEl('label', { text: '阵营名称' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var nameInput = nameRow.createEl('input', { type: 'text', value: nameValue });
        nameInput.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;box-sizing:border-box;';
        nameInput.addEventListener('input', function () { nameValue = nameInput.value; });

        var colorRow = el.createEl('div');
        colorRow.style.cssText = 'margin:10px 0;';
        colorRow.createEl('label', { text: '颜色' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var colorInput = colorRow.createEl('input', { type: 'color', value: colorValue });
        colorInput.addEventListener('input', function () { colorValue = colorInput.value; });

        var descRow = el.createEl('div');
        descRow.style.cssText = 'margin:10px 0;';
        descRow.createEl('label', { text: '描述（可选）' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var descInput = descRow.createEl('textarea', { value: descValue });
        descInput.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;height:60px;box-sizing:border-box;';
        descInput.addEventListener('input', function () { descValue = descInput.value; });

        var btnRow = el.createEl('div');
        btnRow.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:15px;';

        var self = this;
        var saveBtn = btnRow.createEl('button', { text: '保存' });
        saveBtn.style.cssText = 'padding:8px 16px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;';
        saveBtn.addEventListener('click', function () {
            if (!nameValue.trim()) { new obsidian.Notice('请输入名称'); return; }
            self.onSubmit({ name: nameValue.trim(), color: colorValue, desc: descValue.trim() });
            self.close();
        });

        var cancelBtn = btnRow.createEl('button', { text: '取消' });
        cancelBtn.style.cssText = 'padding:8px 16px;border:1px solid #ddd;border-radius:4px;cursor:pointer;background:white;';
        cancelBtn.addEventListener('click', function () { self.close(); });
    };

    FactionModal.prototype.onClose = function () { this.contentEl.empty(); };

    return FactionModal;
}(obsidian.Modal));

// ========== 关系编辑弹窗 ==========
var RelationModal = /** @class */ (function (_super) {
    __extends(RelationModal, _super);
    function RelationModal(app, chars, prefill, relTypes, onSubmit) {
        var _this = _super.call(this, app) || this;
        _this.chars = chars;
        _this.prefill = prefill;
        _this.relTypes = relTypes;
        _this.onSubmit = onSubmit;
        return _this;
    }

    RelationModal.prototype.onOpen = function () {
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;max-height:70vh;overflow-y:auto;';

        el.createEl('h3', { text: this.prefill ? '编辑人物关系' : '添加人物关系' });

        var charA = this.prefill ? this.prefill.charA : (this.chars[0] ? this.chars[0].name : '');
        var charB = this.prefill ? this.prefill.charB : (this.chars[1] ? this.chars[1].name : '');
        var type = this.prefill ? (this.prefill.type || '') : '';
        var desc = this.prefill ? (this.prefill.desc || '') : '';
        var intimacy = (this.prefill && this.prefill.intimacy !== undefined) ? this.prefill.intimacy : 1;
        var startTime = this.prefill ? (this.prefill.startTime || '') : '';
        var endTime = this.prefill ? (this.prefill.endTime || '') : '';

        var rowA = el.createEl('div');
        rowA.style.cssText = 'margin:10px 0;';
        rowA.createEl('label', { text: '人物 A' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var selA = rowA.createEl('select');
        selA.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;';
        for (var i = 0; i < this.chars.length; i++) {
            var opt = selA.createEl('option', { text: this.chars[i].name, value: this.chars[i].name });
            if (this.chars[i].name === charA) opt.selected = true;
        }
        selA.addEventListener('change', function () { charA = selA.value; });

        var rowType = el.createEl('div');
        rowType.style.cssText = 'margin:10px 0;';
        rowType.createEl('label', { text: '关系类型' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var selType = rowType.createEl('select');
        selType.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;';

        var hasMatch = false;
        for (var i = 0; i < this.relTypes.length; i++) {
            var opt = selType.createEl('option', { text: this.relTypes[i], value: this.relTypes[i] });
            if (this.relTypes[i] === type) { opt.selected = true; hasMatch = true; }
        }
        if (!hasMatch && type) {
            selType.createEl('option', { text: type, value: type }).selected = true;
        }
        selType.addEventListener('change', function () { type = selType.value; });

        var rowIntimacy = el.createEl('div');
        rowIntimacy.style.cssText = 'margin:10px 0;';
        rowIntimacy.createEl('label', { text: '亲密度' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var selIntimacy = rowIntimacy.createEl('select');
        selIntimacy.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;';
        for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
            var lvl = INTIMACY_LEVELS[i];
            var opt = selIntimacy.createEl('option', { text: lvl.label + (lvl.value >= 0 ? ' (+' + lvl.value + ')' : ' (' + lvl.value + ')'), value: lvl.value });
            if (lvl.value === intimacy) opt.selected = true;
        }
        selIntimacy.addEventListener('change', function () { intimacy = parseInt(selIntimacy.value); });

        var rowB = el.createEl('div');
        rowB.style.cssText = 'margin:10px 0;';
        rowB.createEl('label', { text: '人物 B' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var selB = rowB.createEl('select');
        selB.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;';
        for (var i = 0; i < this.chars.length; i++) {
            var opt = selB.createEl('option', { text: this.chars[i].name, value: this.chars[i].name });
            if (this.chars[i].name === charB) opt.selected = true;
        }
        selB.addEventListener('change', function () { charB = selB.value; });

        var rowStart = el.createEl('div');
        rowStart.style.cssText = 'margin:10px 0;';
        rowStart.createEl('label', { text: '关系开始时间（可选）' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var startInput = rowStart.createEl('input', { type: 'text', value: startTime, placeholder: '如：301年春、登基后' });
        startInput.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;box-sizing:border-box;';
        startInput.addEventListener('input', function () { startTime = startInput.value; });

        var rowEnd = el.createEl('div');
        rowEnd.style.cssText = 'margin:10px 0;';
        rowEnd.createEl('label', { text: '关系结束时间（可选）' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var endInput = rowEnd.createEl('input', { type: 'text', value: endTime, placeholder: '如：305年秋、决裂后' });
        endInput.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;box-sizing:border-box;';
        endInput.addEventListener('input', function () { endTime = endInput.value; });

        var rowDesc = el.createEl('div');
        rowDesc.style.cssText = 'margin:10px 0;';
        rowDesc.createEl('label', { text: '描述（可选）' }).style.cssText = 'display:block;font-weight:bold;margin-bottom:4px;';
        var descInput = rowDesc.createEl('textarea', { value: desc });
        descInput.style.cssText = 'width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;height:60px;box-sizing:border-box;';
        descInput.addEventListener('input', function () { desc = descInput.value; });

        var btnRow = el.createEl('div');
        btnRow.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:15px;';

        var self = this;
        var saveBtn = btnRow.createEl('button', { text: '保存' });
        saveBtn.style.cssText = 'padding:8px 16px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;';
        saveBtn.addEventListener('click', function () {
            if (!charA || !charB) { new obsidian.Notice('请选择人物'); return; }
            if (charA === charB) { new obsidian.Notice('不能选同一个人'); return; }
            if (!type) { new obsidian.Notice('请选择关系类型'); return; }
            self.onSubmit({ charA: charA, charB: charB, type: type, desc: desc.trim(), intimacy: intimacy, startTime: startTime, endTime: endTime });
            self.close();
        });

        var cancelBtn = btnRow.createEl('button', { text: '取消' });
        cancelBtn.style.cssText = 'padding:8px 16px;border:1px solid #ddd;border-radius:4px;cursor:pointer;background:white;';
        cancelBtn.addEventListener('click', function () { self.close(); });
    };

    RelationModal.prototype.onClose = function () { this.contentEl.empty(); };

    return RelationModal;
}(obsidian.Modal));

// ========== 批量操作弹窗 ==========
var BatchRelationModal = /** @class */ (function (_super) {
    __extends(BatchRelationModal, _super);
    function BatchRelationModal(app, relations, chars, onConfirm) {
        var _this = _super.call(this, app) || this;
        _this.relations = relations;
        _this.chars = chars;
        _this.onConfirm = onConfirm;
        return _this;
    }

    BatchRelationModal.prototype.onOpen = function () {
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;min-width:300px;';
        
        el.createEl('h3', { text: '⚡ 批量操作' }).style.cssText = 'margin:0 0 15px;border-bottom:1px solid #eee;padding-bottom:8px;';
        
        var typeSet = {};
        for (var i = 0; i < this.relations.length; i++) {
            var t = this.relations[i].type || '其他';
            typeSet[t] = true;
        }
        var types = Object.keys(typeSet).sort();
        
        if (types.length > 0) {
            var deleteSection = el.createEl('div');
            deleteSection.style.cssText = 'margin-bottom:20px;padding:10px;background:#fef5f5;border-radius:6px;border-left:3px solid #e74c3c;';
            deleteSection.createEl('div', { text: '🗑️ 按类型批量删除' }).style.cssText = 'font-size:13px;font-weight:bold;margin-bottom:8px;color:#e74c3c;';
            
            var typeSelect1 = deleteSection.createEl('select');
            typeSelect1.style.cssText = 'width:100%;padding:6px;margin-bottom:8px;border-radius:4px;border:1px solid #ddd;';
            for (var i = 0; i < types.length; i++) {
                typeSelect1.add(createOption(types[i], types[i]));
            }
            
            var delBtn = deleteSection.createEl('button', { text: '删除此类型所有关系' });
            delBtn.style.cssText = 'padding:6px 12px;background:#e74c3c;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
            var self = this;
            delBtn.addEventListener('click', function() {
                var selectedType = typeSelect1.value;
                if (confirm('确定删除所有「' + selectedType + '」类型的关系吗？')) {
                    self.onConfirm({ action: 'batch_delete_by_type', type: selectedType });
                    self.close();
                }
            });
        }
        
        if (types.length > 0) {
            var updateSection = el.createEl('div');
            updateSection.style.cssText = 'margin-bottom:20px;padding:10px;background:#f5fef5;border-radius:6px;border-left:3px solid #27ae60;';
            updateSection.createEl('div', { text: '📝 按类型批量更新亲密度' }).style.cssText = 'font-size:13px;font-weight:bold;margin-bottom:8px;color:#27ae60;';
            
            var typeSelect2 = updateSection.createEl('select');
            typeSelect2.style.cssText = 'width:100%;padding:6px;margin-bottom:8px;border-radius:4px;border:1px solid #ddd;';
            for (var i = 0; i < types.length; i++) {
                typeSelect2.add(createOption(types[i], types[i]));
            }
            
            var intimacySelect = updateSection.createEl('select');
            intimacySelect.style.cssText = 'width:100%;padding:6px;margin-bottom:8px;border-radius:4px;border:1px solid #ddd;';
            for (var i = 0; i < INTIMACY_LEVELS.length; i++) {
                var lvl = INTIMACY_LEVELS[i];
                intimacySelect.add(createOption(lvl.value.toString(), lvl.label));
            }
            
            var updateBtn = updateSection.createEl('button', { text: '更新此类型所有关系的亲密度' });
            updateBtn.style.cssText = 'padding:6px 12px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
            var self = this;
            updateBtn.addEventListener('click', function() {
                var selectedType = typeSelect2.value;
                var newIntimacy = parseInt(intimacySelect.value);
                if (confirm('确定将「' + selectedType + '」类型的所有关系亲密度改为 ' + getIntimacyLabel(newIntimacy) + ' 吗？')) {
                    self.onConfirm({ action: 'batch_update_intimacy', type: selectedType, newIntimacy: newIntimacy });
                    self.close();
                }
            });
        }
        
        var statsSection = el.createEl('div');
        statsSection.style.cssText = 'margin-bottom:20px;padding:10px;background:#f0f4ff;border-radius:6px;';
        statsSection.createEl('div', { text: '📊 统计信息' }).style.cssText = 'font-size:13px;font-weight:bold;margin-bottom:8px;';
        
        var typeStats = {};
        for (var i = 0; i < this.relations.length; i++) {
            var t = this.relations[i].type || '其他';
            typeStats[t] = (typeStats[t] || 0) + 1;
        }
        var typeList = Object.keys(typeStats).sort();
        for (var i = 0; i < typeList.length; i++) {
            statsSection.createEl('div', { text: typeList[i] + ': ' + typeStats[typeList[i]] + '条' }).style.cssText = 'font-size:11px;color:#666;';
        }
        
        var dangerSection = el.createEl('div');
        dangerSection.style.cssText = 'margin-bottom:20px;padding:10px;background:#fff5f0;border-radius:6px;border-left:3px solid #e67e22;';
        var clearBtn = dangerSection.createEl('button', { text: '⚠️ 清空所有关系（不可恢复）' });
        clearBtn.style.cssText = 'padding:6px 12px;background:#e67e22;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
        var self = this;
        clearBtn.addEventListener('click', function() {
            self.onConfirm({ action: 'clear_all' });
            self.close();
        });
        
        var exportSection = el.createEl('div');
        exportSection.style.cssText = 'padding:10px;background:#f5f5f5;border-radius:6px;';
        var exportBtn = exportSection.createEl('button', { text: '📎 导出所有关系为 CSV' });
        exportBtn.style.cssText = 'padding:6px 12px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
        exportBtn.addEventListener('click', function() {
            self.onConfirm({ action: 'export_relations' });
            self.close();
        });
        
        var closeBtn = el.createEl('button', { text: '关闭' });
        closeBtn.style.cssText = 'margin-top:15px;padding:8px 16px;background:#888;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
        closeBtn.addEventListener('click', function() { self.close(); });
    };
    
    BatchRelationModal.prototype.onClose = function() {
        this.contentEl.empty();
    };
    
    return BatchRelationModal;
}(obsidian.Modal));

// ========== 人物详情弹窗 ==========
var DetailModal = /** @class */ (function (_super) {
    __extends(DetailModal, _super);
    function DetailModal(app, charData, events, relations, manualRels, view) {
        var _this = _super.call(this, app) || this;
        _this.charData = charData;
        _this.events = events;
        _this.relations = relations;
        _this.manualRels = manualRels;
        _this.view = view;
        return _this;
    }

    DetailModal.prototype.onOpen = function () {
        var self = this;
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;max-height:70vh;overflow-y:auto;min-width:300px;';

        el.createEl('h2', { text: this.charData.name }).style.cssText = 'margin:0 0 15px;border-bottom:2px solid var(--interactive-accent);padding-bottom:6px;';

        var infoDiv = el.createEl('div', { cls: 'my-char-detail-panel' });

        var fields = this.charData.fields;
        var customFields = this.view.plugin.settings.customFields || '';
        var fieldOrder = customFields ? customFields.split(',').map(function(s) { return s.trim(); }) : 
            ['身份', '阵营', '首次出场', '死亡', '死亡时间', '出生', '出生时间', '年龄', '性别', '种族', '职业', '居住地', '别名', '亲密人物'];
        
        var displayed = [];

        for (var i = 0; i < fieldOrder.length; i++) {
            var key = fieldOrder[i];
            if (fields[key]) {
                displayed.push(key);
                var row = infoDiv.createEl('div');
                row.style.cssText = 'margin-bottom:6px;font-size:13px;';
                row.createEl('strong', { text: key + '：' }).style.cssText = 'display:inline-block;width:70px;color:#555;';
                row.createEl('span', { text: fields[key] });
            }
        }
        for (var key in fields) {
            if (fields.hasOwnProperty(key) && displayed.indexOf(key) === -1) {
                var row = infoDiv.createEl('div');
                row.style.cssText = 'margin-bottom:6px;font-size:13px;';
                row.createEl('strong', { text: key + '：' }).style.cssText = 'display:inline-block;width:70px;color:#555;';
                row.createEl('span', { text: fields[key] });
            }
        }

        if (Object.keys(fields).length === 0) {
            infoDiv.createEl('p', { text: '暂无其他信息' }).style.cssText = 'color:var(--text-muted);font-size:12px;text-align:center;';
        }

        var lc = getCharLifecycle(this.view, this.charData);
        if (lc.birth || lc.firstAppear || lc.death) {
            el.createEl('h3', { text: '⏳ 生命周期' }).style.cssText = 'margin:12px 0 6px;font-size:15px;';
            var lcPanel = el.createEl('div', { cls: 'my-char-detail-panel' });
            if (lc.birth) {
                var birthRow = lcPanel.createEl('div');
                birthRow.createEl('strong', { text: '出生：' });
                birthRow.createEl('span', { text: lc.birth });
                if (lc.birthParsed && lc.birthParsed.sortValue !== null) {
                    birthRow.createEl('small', { text: ' (' + formatSortValue(lc.birthParsed.sortValue) + ')', cls: 'my-char-view-muted' });
                }
            }
            if (lc.firstAppear) {
                var appearRow = lcPanel.createEl('div');
                appearRow.createEl('strong', { text: '首次出场：' });
                appearRow.createEl('span', { text: lc.firstAppear });
                if (lc.firstAppearParsed && lc.firstAppearParsed.sortValue !== null) {
                    appearRow.createEl('small', { text: ' (' + formatSortValue(lc.firstAppearParsed.sortValue) + ')', cls: 'my-char-view-muted' });
                }
            }
            if (lc.death) {
                var deathRow = lcPanel.createEl('div');
                deathRow.createEl('strong', { text: '死亡：' });
                deathRow.createEl('span', { text: lc.death });
                if (lc.deathParsed && lc.deathParsed.sortValue !== null) {
                    deathRow.createEl('small', { text: ' (' + formatSortValue(lc.deathParsed.sortValue) + ')', cls: 'my-char-view-muted' });
                }
            }
        }

        if (this.manualRels.length > 0) {
            el.createEl('h3', { text: '人物关系 (' + this.manualRels.length + ')' }).style.cssText = 'margin:12px 0 6px;font-size:15px;';
            for (var i = 0; i < this.manualRels.length; i++) {
                var rel = this.manualRels[i];
                var other = rel.charA === this.charData.name ? rel.charB : rel.charA;
                var item = el.createEl('div');
                item.style.cssText = 'padding:8px 10px;margin:3px 0;border:1px solid #e0e0e0;border-radius:4px;';
                
                var intimacyVal = (rel.intimacy !== undefined) ? rel.intimacy : 0;
                var intimacyLabel = getIntimacyLabel(intimacyVal);
                var intimacyColor = getIntimacyColor(intimacyVal);

                var otherLink = item.createEl('strong', { text: other, cls: 'my-char-view-link' });
                var typeBadge = item.createEl('span', { text: rel.type });
                typeBadge.style.cssText = 'background:var(--interactive-accent);color:var(--text-on-accent);padding:2px 8px;border-radius:10px;font-size:11px;margin-left:6px;';
                var intimacyBadge = item.createEl('span', { text: '❤️ ' + intimacyLabel });
                intimacyBadge.style.cssText = 'padding:2px 6px;border-radius:8px;font-size:10px;color:white;background:' + intimacyColor + ';margin-left:4px;';
                if (rel.desc) {
                    item.createEl('div', { text: rel.desc }).style.cssText = 'font-size:12px;color:#666;margin-top:4px;';
                }
                if (rel.startTime || rel.endTime) {
                    var timeText = '';
                    if (rel.startTime) timeText += '📅 始于 ' + rel.startTime;
                    if (rel.endTime) timeText += (timeText ? ' · ' : '') + '⌛ 止于 ' + rel.endTime;
                    item.createEl('div', { text: timeText }).style.cssText = 'font-size:10px;color:#888;margin-top:2px;';
                }
                
                otherLink.addEventListener('click', (function(targetName) {
                    return function() {
                        var targetChar = self.view.findChar(targetName);
                        if (targetChar) {
                            self.close();
                            self.view.showCharDetail(targetChar);
                        }
                    };
                })(other));
            }
        }

        var relNames = Object.keys(this.relations);
        if (relNames.length > 0) {
            el.createEl('h3', { text: '共同出场人物 (' + relNames.length + '人)' }).style.cssText = 'margin:12px 0 6px;font-size:15px;';
            for (var i = 0; i < relNames.length; i++) {
                var name = relNames[i];
                var evts = this.relations[name];
                var item = el.createEl('div');
                item.style.cssText = 'padding:6px 10px;margin:3px 0;background:#f9f9f9;border-radius:4px;';
                item.createEl('strong', { text: name }).style.cssText = 'cursor:pointer;color:#4a90e2;text-decoration:underline;';
                item.createEl('div', { text: '共同出场: ' + evts.length + '次' }).style.cssText = 'font-size:12px;color:#666;';
                
                item.querySelector('strong').addEventListener('click', (function(targetName) {
                    return function() {
                        var targetChar = self.view.findChar(targetName);
                        if (targetChar) {
                            self.close();
                            self.view.showCharDetail(targetChar);
                        }
                    };
                })(name));
            }
        }

        if (this.events.length > 0) {
            el.createEl('h3', { text: '时间线出场 (' + this.events.length + '次)' }).style.cssText = 'margin:12px 0 6px;font-size:15px;';
            var showCount = Math.min(50, this.events.length);
            for (var i = 0; i < showCount; i++) {
                var item = el.createEl('div');
                item.style.cssText = 'padding:4px 8px;margin:2px 0;background:#fafafa;border-radius:3px;font-size:12px;';
                item.createEl('small', { text: '[' + this.events[i].year + ' ' + this.events[i].month + '] ' }).style.color = '#999';
                item.createEl('span', { text: this.events[i].event });
            }
            if (this.events.length > 50) {
                el.createEl('p', { text: '...还有 ' + (this.events.length - 50) + ' 条' }).style.cssText = 'color:#888;font-size:12px;';
            }
        }
        
        var closeBtn = el.createEl('button', { text: '关闭', cls: 'my-char-view-btn' });
        closeBtn.style.cssText = 'margin-top:15px;width:100%;';
        closeBtn.addEventListener('click', function () { self.close(); });
    };

    DetailModal.prototype.onClose = function () { this.contentEl.empty(); };

    return DetailModal;
}(obsidian.Modal));

// ========== 自定义事件标签管理弹窗（完全自由版）==========
var EventTagModal = /** @class */ (function (_super) {
    __extends(EventTagModal, _super);
    function EventTagModal(app, plugin, onSave) {
        var _this = _super.call(this, app) || this;
        _this.plugin = plugin;
        _this.onSave = onSave;
        
        // 直接从设置加载，没有默认限制
        var customTags = plugin.settings.customEventTags || [];
        if (customTags.length === 0) {
            // 首次使用，预置默认标签
            _this.tempTags = JSON.parse(JSON.stringify(DEFAULT_EVENT_TAGS));
        } else {
            _this.tempTags = JSON.parse(JSON.stringify(customTags));
        }
        return _this;
    }

    EventTagModal.prototype.onOpen = function () {
        var self = this;
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;min-width:500px;max-height:85vh;overflow-y:auto;';
        
        el.createEl('h3', { text: '🏷️ 管理事件标签' }).style.cssText = 'margin:0 0 10px;border-bottom:1px solid #eee;padding-bottom:8px;';
        
        var desc = el.createEl('p', { text: '完全自由管理所有标签。添加、编辑、删除任意标签，随心所欲。' });
        desc.style.cssText = 'font-size:12px;color:#666;margin-bottom:12px;';
        
        var tip = el.createEl('div');
        tip.style.cssText = 'background:#f0f7ff;padding:8px 12px;border-radius:6px;font-size:11px;color:#555;margin-bottom:15px;border-left:3px solid #4a90e2;';
        tip.innerHTML = '💡 在时间线文件中使用 <code>[标签值]</code> 格式标记事件，如：<code>- [战争] 张三出征</code><br>所有标签都可以自由添加、删除、修改！';

        var tagsContainer = el.createEl('div');
        tagsContainer.style.cssText = 'margin-bottom:12px;max-height:350px;overflow-y:auto;border:1px solid #e8e8e8;border-radius:6px;padding:10px;background:#fafafa;';
        
        function renderTagList() {
            tagsContainer.empty();
            
            if (self.tempTags.length === 0) {
                var emptyMsg = tagsContainer.createEl('div');
                emptyMsg.style.cssText = 'text-align:center;color:#999;padding:30px 10px;font-size:13px;';
                emptyMsg.innerHTML = '📭 暂无标签<br><span style="font-size:11px;">点击下方 "添加标签" 创建新标签</span>';
                return;
            }
            
            // 按标签值排序
            self.tempTags.sort(function(a, b) { return a.value.localeCompare(b.value); });
            
            for (var i = 0; i < self.tempTags.length; i++) {
                (function(idx) {
                    var tag = self.tempTags[idx];
                    
                    var row = tagsContainer.createEl('div');
                    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;padding:8px 10px;background:white;border-radius:6px;align-items:center;flex-wrap:wrap;border:1px solid #e8e8e8;';
                    
                    var colorPreview = row.createEl('span');
                    colorPreview.style.cssText = 'display:inline-block;width:16px;height:16px;border-radius:50%;background:' + (tag.color || '#4a90e2') + ';border:1px solid #ddd;flex-shrink:0;';
                    
                    var valueInput = row.createEl('input', { type: 'text', value: tag.value, placeholder: '标签值（唯一标识）' });
                    valueInput.style.cssText = 'flex:1;min-width:70px;padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;';
                    valueInput.addEventListener('change', function() {
                        var newValue = valueInput.value.trim();
                        if (newValue) {
                            // 检查冲突
                            var conflict = false;
                            for (var j = 0; j < self.tempTags.length; j++) {
                                if (j !== idx && self.tempTags[j].value === newValue) {
                                    conflict = true;
                                    break;
                                }
                            }
                            if (!conflict) {
                                self.tempTags[idx].value = newValue;
                            } else {
                                new obsidian.Notice('标签值 "' + newValue + '" 已存在');
                                valueInput.value = self.tempTags[idx].value;
                            }
                        }
                    });
                    
                    var labelInput = row.createEl('input', { type: 'text', value: tag.label || tag.value, placeholder: '显示文字' });
                    labelInput.style.cssText = 'flex:1;min-width:70px;padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;';
                    labelInput.addEventListener('change', function() {
                        self.tempTags[idx].label = labelInput.value.trim() || labelInput.value;
                    });
                    
                    var colorInput = row.createEl('input', { type: 'color', value: tag.color || '#4a90e2' });
                    colorInput.style.cssText = 'width:36px;height:30px;border:1px solid #ddd;border-radius:4px;cursor:pointer;padding:0;';
                    colorInput.addEventListener('change', function() {
                        self.tempTags[idx].color = colorInput.value;
                        colorPreview.style.background = colorInput.value;
                    });
                    
                    var delBtn = row.createEl('button', { text: '✕' });
                    delBtn.style.cssText = 'padding:2px 8px;background:#e74c3c;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;line-height:1.4;';
                    delBtn.addEventListener('click', function() {
                        self.tempTags.splice(idx, 1);
                        renderTagList();
                    });
                })(i);
            }
        }
        
        renderTagList();
        
        var btnRow1 = el.createEl('div');
        btnRow1.style.cssText = 'display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;';
        
        var addBtn = btnRow1.createEl('button', { text: '+ 添加标签' });
        addBtn.style.cssText = 'flex:1;padding:8px 16px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;';
        addBtn.addEventListener('click', function() {
            self.tempTags.push({ value: '新标签_' + Date.now(), label: '🏷️ 新标签', color: '#4a90e2' });
            renderTagList();
            tagsContainer.scrollTop = tagsContainer.scrollHeight;
        });
        
        var resetBtn = btnRow1.createEl('button', { text: '↺ 重置为默认标签' });
        resetBtn.style.cssText = 'padding:8px 16px;background:#e67e22;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;';
        resetBtn.addEventListener('click', function() {
            if (confirm('重置将覆盖当前所有标签，确定吗？')) {
                self.tempTags = JSON.parse(JSON.stringify(DEFAULT_EVENT_TAGS));
                renderTagList();
            }
        });
        
        var btnRow2 = el.createEl('div');
        btnRow2.style.cssText = 'display:flex;gap:10px;margin-top:5px;';
        
        var saveBtn = btnRow2.createEl('button', { text: '✅ 保存' });
        saveBtn.style.cssText = 'flex:2;padding:10px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        saveBtn.addEventListener('click', function() {
            var validTags = [];
            for (var i = 0; i < self.tempTags.length; i++) {
                var tag = self.tempTags[i];
                if (tag.value && tag.value.trim()) {
                    validTags.push({
                        value: tag.value.trim(),
                        label: tag.label || tag.value.trim(),
                        color: tag.color || '#4a90e2'
                    });
                }
            }
            
            self.plugin.settings.customEventTags = validTags;
            self.plugin.saveSettings();
            invalidateTagCache(self.plugin);
            if (self.onSave) self.onSave();
            self.close();
            new obsidian.Notice('标签已保存！共 ' + validTags.length + ' 个标签');
        });
        
        var cancelBtn = btnRow2.createEl('button', { text: '取消' });
        cancelBtn.style.cssText = 'flex:1;padding:10px;background:#888;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        cancelBtn.addEventListener('click', function() { self.close(); });
    };
    
    EventTagModal.prototype.onClose = function() {
        this.contentEl.empty();
    };
    
    return EventTagModal;
}(obsidian.Modal));

// ========== 关系类型管理弹窗 ==========
var RelationTypeModal = /** @class */ (function (_super) {
    __extends(RelationTypeModal, _super);
    function RelationTypeModal(app, plugin, onSave) {
        var _this = _super.call(this, app) || this;
        _this.plugin = plugin;
        _this.onSave = onSave;
        var existing = plugin.settings.customRelationTypes || '';
        _this.tempTypes = existing ? existing.split(',').map(function(s) { return s.trim(); }) : 
            ['父子', '母子', '父女', '母女', '兄弟', '姐妹', '夫妻', '恋人', '朋友', '敌人'];
        return _this;
    }

    RelationTypeModal.prototype.onOpen = function () {
        var self = this;
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;min-width:400px;max-height:80vh;overflow-y:auto;';
        
        el.createEl('h3', { text: '📌 管理关系类型' }).style.cssText = 'margin:0 0 12px;border-bottom:1px solid #eee;padding-bottom:8px;';
        
        var helpText = el.createEl('p', { text: '添加、编辑或删除关系类型。这些类型将显示在关系编辑下拉菜单中。' });
        helpText.style.cssText = 'font-size:12px;color:#666;margin-bottom:12px;';
        
        var container = el.createEl('div');
        container.style.cssText = 'margin-bottom:12px;max-height:300px;overflow-y:auto;border:1px solid #e8e8e8;border-radius:6px;padding:10px;background:#fafafa;';
        
        function renderList() {
            container.empty();
            if (self.tempTypes.length === 0) {
                var emptyMsg = container.createEl('div');
                emptyMsg.style.cssText = 'text-align:center;color:#999;padding:20px;';
                emptyMsg.createEl('span', { text: '暂无关系类型，点击下方按钮添加' });
                return;
            }
            for (var i = 0; i < self.tempTypes.length; i++) {
                (function(idx) {
                    var row = container.createEl('div');
                    row.style.cssText = 'display:flex;gap:8px;margin-bottom:6px;align-items:center;';
                    
                    var input = row.createEl('input', { type: 'text', value: self.tempTypes[idx] });
                    input.style.cssText = 'flex:1;padding:6px 10px;border:1px solid #ddd;border-radius:4px;font-size:13px;';
                    input.addEventListener('change', function() {
                        self.tempTypes[idx] = input.value.trim();
                    });
                    
                    var delBtn = row.createEl('button', { text: '✕' });
                    delBtn.style.cssText = 'padding:2px 10px;background:#e74c3c;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
                    delBtn.addEventListener('click', function() {
                        self.tempTypes.splice(idx, 1);
                        renderList();
                    });
                })(i);
            }
        }
        renderList();
        
        var addBtn = el.createEl('button', { text: '+ 添加类型' });
        addBtn.style.cssText = 'padding:8px 16px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;margin-bottom:12px;width:100%;font-size:13px;';
        addBtn.addEventListener('click', function() {
            self.tempTypes.push('新类型');
            renderList();
            container.scrollTop = container.scrollHeight;
        });
        
        var btnRow = el.createEl('div');
        btnRow.style.cssText = 'display:flex;gap:10px;margin-top:5px;';
        
        var saveBtn = btnRow.createEl('button', { text: '✅ 保存' });
        saveBtn.style.cssText = 'flex:2;padding:10px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        saveBtn.addEventListener('click', function() {
            var validTypes = self.tempTypes.filter(function(t) { return t && t.trim(); });
            self.plugin.settings.customRelationTypes = validTypes.join(',');
            self.plugin.saveSettings();
            if (self.onSave) self.onSave();
            self.close();
            new obsidian.Notice('关系类型已保存');
        });
        
        var cancelBtn = btnRow.createEl('button', { text: '取消' });
        cancelBtn.style.cssText = 'flex:1;padding:10px;background:#888;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        cancelBtn.addEventListener('click', function() { self.close(); });
    };
    
    RelationTypeModal.prototype.onClose = function() {
        this.contentEl.empty();
    };
    
    return RelationTypeModal;
}(obsidian.Modal));

// ========== 亲密度等级管理弹窗 ==========
var IntimacyLevelModal = /** @class */ (function (_super) {
    __extends(IntimacyLevelModal, _super);
    function IntimacyLevelModal(app, plugin, onSave) {
        var _this = _super.call(this, app) || this;
        _this.plugin = plugin;
        _this.onSave = onSave;
        var existing = plugin.settings.customIntimacyLevels || '';
        if (existing) {
            var parts = existing.split(',').map(function(s) { return s.trim(); });
            _this.tempLevels = [];
            for (var i = 0; i < parts.length; i++) {
                var p = parts[i].split(':');
                if (p.length >= 3) {
                    _this.tempLevels.push({
                        value: parseInt(p[0]),
                        label: p[1],
                        color: p[2]
                    });
                }
            }
            if (_this.tempLevels.length === 0) {
                _this.tempLevels = [
                    { value: -3, label: '仇恨', color: '#c0392b' },
                    { value: -2, label: '厌恶', color: '#e67e22' },
                    { value: -1, label: '冷淡', color: '#f39c12' },
                    { value: 0, label: '陌生', color: '#95a5a6' },
                    { value: 1, label: '认识', color: '#4a90e2' },
                    { value: 2, label: '一般', color: '#2ecc71' },
                    { value: 3, label: '友好', color: '#27ae60' },
                    { value: 4, label: '亲密', color: '#e74c3c' },
                    { value: 5, label: '挚友', color: '#9b59b6' }
                ];
            }
        } else {
            _this.tempLevels = [
                { value: -3, label: '仇恨', color: '#c0392b' },
                { value: -2, label: '厌恶', color: '#e67e22' },
                { value: -1, label: '冷淡', color: '#f39c12' },
                { value: 0, label: '陌生', color: '#95a5a6' },
                { value: 1, label: '认识', color: '#4a90e2' },
                { value: 2, label: '一般', color: '#2ecc71' },
                { value: 3, label: '友好', color: '#27ae60' },
                { value: 4, label: '亲密', color: '#e74c3c' },
                { value: 5, label: '挚友', color: '#9b59b6' }
            ];
        }
        return _this;
    }

    IntimacyLevelModal.prototype.onOpen = function () {
        var self = this;
        var el = this.contentEl;
        el.style.cssText = 'padding:20px;min-width:500px;max-height:80vh;overflow-y:auto;';
        
        el.createEl('h3', { text: '❤️ 管理亲密度等级' }).style.cssText = 'margin:0 0 12px;border-bottom:1px solid #eee;padding-bottom:8px;';
        
        var helpText = el.createEl('p', { text: '添加、编辑或删除亲密度等级。数值越小表示关系越疏远，越大表示越亲密。' });
        helpText.style.cssText = 'font-size:12px;color:#666;margin-bottom:12px;';
        
        var container = el.createEl('div');
        container.style.cssText = 'margin-bottom:12px;max-height:350px;overflow-y:auto;border:1px solid #e8e8e8;border-radius:6px;padding:10px;background:#fafafa;';
        
        function renderList() {
            container.empty();
            
            if (self.tempLevels.length === 0) {
                var emptyMsg = container.createEl('div');
                emptyMsg.style.cssText = 'text-align:center;color:#999;padding:20px;';
                emptyMsg.createEl('span', { text: '暂无亲密度等级，点击下方按钮添加' });
                return;
            }
            
            self.tempLevels.sort(function(a, b) { return a.value - b.value; });
            
            for (var i = 0; i < self.tempLevels.length; i++) {
                (function(idx) {
                    var level = self.tempLevels[idx];
                    var row = container.createEl('div');
                    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;padding:8px 10px;background:white;border-radius:6px;align-items:center;flex-wrap:wrap;border:1px solid #e8e8e8;';
                    
                    var colorPreview = row.createEl('span');
                    colorPreview.style.cssText = 'display:inline-block;width:16px;height:16px;border-radius:50%;background:' + (level.color || '#4a90e2') + ';border:1px solid #ddd;flex-shrink:0;';
                    
                    var valueInput = row.createEl('input', { type: 'number', value: level.value, placeholder: '数值' });
                    valueInput.style.cssText = 'width:60px;padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;';
                    valueInput.addEventListener('change', function() {
                        self.tempLevels[idx].value = parseInt(valueInput.value) || 0;
                    });
                    
                    var labelInput = row.createEl('input', { type: 'text', value: level.label, placeholder: '标签（如：亲密）' });
                    labelInput.style.cssText = 'flex:1;min-width:80px;padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;';
                    labelInput.addEventListener('change', function() {
                        self.tempLevels[idx].label = labelInput.value.trim() || labelInput.value;
                    });
                    
                    var colorInput = row.createEl('input', { type: 'color', value: level.color || '#4a90e2' });
                    colorInput.style.cssText = 'width:36px;height:30px;border:1px solid #ddd;border-radius:4px;cursor:pointer;padding:0;';
                    colorInput.addEventListener('change', function() {
                        self.tempLevels[idx].color = colorInput.value;
                        colorPreview.style.background = colorInput.value;
                    });
                    
                    var delBtn = row.createEl('button', { text: '✕' });
                    delBtn.style.cssText = 'padding:2px 8px;background:#e74c3c;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
                    delBtn.addEventListener('click', function() {
                        self.tempLevels.splice(idx, 1);
                        renderList();
                    });
                })(i);
            }
        }
        
        renderList();
        
        var btnRow1 = el.createEl('div');
        btnRow1.style.cssText = 'display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;';
        
        var addBtn = btnRow1.createEl('button', { text: '+ 添加等级' });
        addBtn.style.cssText = 'flex:1;padding:8px 16px;background:#27ae60;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;';
        addBtn.addEventListener('click', function() {
            var maxVal = 0;
            for (var i = 0; i < self.tempLevels.length; i++) {
                if (self.tempLevels[i].value > maxVal) maxVal = self.tempLevels[i].value;
            }
            self.tempLevels.push({ value: maxVal + 1, label: '新等级', color: '#4a90e2' });
            renderList();
            container.scrollTop = container.scrollHeight;
        });
        
        var resetBtn = btnRow1.createEl('button', { text: '↺ 恢复默认' });
        resetBtn.style.cssText = 'padding:8px 16px;background:#e67e22;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;';
        resetBtn.addEventListener('click', function() {
            if (confirm('恢复默认将清除所有自定义等级，确定吗？')) {
                self.tempLevels = [
                    { value: -3, label: '仇恨', color: '#c0392b' },
                    { value: -2, label: '厌恶', color: '#e67e22' },
                    { value: -1, label: '冷淡', color: '#f39c12' },
                    { value: 0, label: '陌生', color: '#95a5a6' },
                    { value: 1, label: '认识', color: '#4a90e2' },
                    { value: 2, label: '一般', color: '#2ecc71' },
                    { value: 3, label: '友好', color: '#27ae60' },
                    { value: 4, label: '亲密', color: '#e74c3c' },
                    { value: 5, label: '挚友', color: '#9b59b6' }
                ];
                renderList();
            }
        });
        
        var btnRow2 = el.createEl('div');
        btnRow2.style.cssText = 'display:flex;gap:10px;margin-top:5px;';
        
        var saveBtn = btnRow2.createEl('button', { text: '✅ 保存' });
        saveBtn.style.cssText = 'flex:2;padding:10px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        saveBtn.addEventListener('click', function() {
            var validLevels = [];
            for (var i = 0; i < self.tempLevels.length; i++) {
                var lvl = self.tempLevels[i];
                if (lvl.label && lvl.label.trim()) {
                    validLevels.push({
                        value: lvl.value,
                        label: lvl.label.trim(),
                        color: lvl.color || '#4a90e2'
                    });
                }
            }
            validLevels.sort(function(a, b) { return a.value - b.value; });
            
            var str = validLevels.map(function(l) {
                return l.value + ':' + l.label + ':' + l.color;
            }).join(',');
            
            self.plugin.settings.customIntimacyLevels = str;
            self.plugin.saveSettings();
            updateIntimacyLevels(str);
            if (self.onSave) self.onSave();
            self.close();
            new obsidian.Notice('亲密度等级已保存');
        });
        
        var cancelBtn = btnRow2.createEl('button', { text: '取消' });
        cancelBtn.style.cssText = 'flex:1;padding:10px;background:#888;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;';
        cancelBtn.addEventListener('click', function() { self.close(); });
    };
    
    IntimacyLevelModal.prototype.onClose = function() {
        this.contentEl.empty();
    };
    
    return IntimacyLevelModal;
}(obsidian.Modal));

// ========== 设置页 ==========
var SettingTab = /** @class */ (function (_super) {
    __extends(SettingTab, _super);
    function SettingTab(app, plugin) {
        var _this = _super.call(this, app, plugin) || this;
        _this.plugin = plugin;
        return _this;
    }

    SettingTab.prototype.display = function () {
        var el = this.containerEl;
        var self = this;
        el.empty();
        el.createEl('h2', { text: '人物关系谱系 - 设置' });

        el.createEl('h3', { text: '📄 人物文件配置' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;color:#4a90e2;';
        
        new obsidian.Setting(el)
            .setName('人物索引文件夹路径')
            .setDesc('存放人物索引文件的文件夹路径（相对于仓库根目录），留空表示使用根目录')
            .addText(function (text) {
                text.setPlaceholder('例如：人物资料 或 Worldbuilding/Characters')
                    .setValue(this.plugin.settings.charFolder || '')
                    .onChange(async function (value) {
                        var cleanPath = value.replace(/^\/+/, '').replace(/\/+$/, '');
                        this.plugin.settings.charFolder = cleanPath;
                        await this.plugin.saveSettings();
                        this.updatePathHint();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('人物索引文件名')
            .setDesc('人物索引文件的名称')
            .addText(function (text) {
                text.setPlaceholder('人物索引.md')
                    .setValue(this.plugin.settings.charFile)
                    .onChange(async function (value) {
                        this.plugin.settings.charFile = value;
                        await this.plugin.saveSettings();
                        this.updatePathHint();
                    }.bind(this));
            }.bind(this));

        el.createEl('h3', { text: '📅 时间线文件配置' }).style.cssText = 'margin-top:20px;font-size:14px;font-weight:bold;color:#27ae60;';
        
        new obsidian.Setting(el)
            .setName('时间线文件夹路径')
            .setDesc('存放时间线文件的文件夹路径（相对于仓库根目录），留空表示使用根目录')
            .addText(function (text) {
                text.setPlaceholder('例如：时间线 或 Worldbuilding/Timeline')
                    .setValue(this.plugin.settings.timelineFolder || '')
                    .onChange(async function (value) {
                        var cleanPath = value.replace(/^\/+/, '').replace(/\/+$/, '');
                        this.plugin.settings.timelineFolder = cleanPath;
                        await this.plugin.saveSettings();
                        this.updatePathHint();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('时间线文件名')
            .setDesc('时间线文件的名称')
            .addText(function (text) {
                text.setPlaceholder('时间线.md')
                    .setValue(this.plugin.settings.timelineFile)
                    .onChange(async function (value) {
                        this.plugin.settings.timelineFile = value;
                        await this.plugin.saveSettings();
                        this.updatePathHint();
                    }.bind(this));
            }.bind(this));

        var pathHint = el.createEl('div');
        pathHint.style.cssText = 'margin:10px 0 15px;padding:10px;background:#f0f4ff;border-radius:6px;font-size:12px;color:#333;border-left:3px solid #4a90e2;';
        
        this.updatePathHint = function() {
            var charFullPath = getCharFullPath(this.plugin);
            var timelineFullPath = getTimelineFullPath(this.plugin);
            pathHint.innerHTML = '📍 <strong>当前完整路径</strong><br>' +
                '• 👥 人物文件：<code style="background:#e0e0e0;padding:2px 4px;border-radius:3px;">' + charFullPath + '</code><br>' +
                '• 📅 时间线文件：<code style="background:#e0e0e0;padding:2px 4px;border-radius:3px;">' + timelineFullPath + '</code>';
        }.bind(this);
        this.updatePathHint();

        el.createEl('hr');

        el.createEl('h3', { text: '🏷️ 事件标签配置' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;color:#9b59b6;';
        
        new obsidian.Setting(el)
            .setName('管理事件标签（可视化）')
            .setDesc('完全自由添加、编辑或删除时间线事件标签')
            .addButton(function (btn) {
                btn.setButtonText('🏷️ 管理标签')
                    .setCta()
                    .onClick(function () {
                        var modal = new EventTagModal(self.app, self.plugin, function() {
                            invalidateTagCache(self.plugin);
                            refreshCharView(self.app);
                        });
                        modal.open();
                    });
            });

        el.createEl('hr');

        el.createEl('h3', { text: '📌 关系类型配置' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;color:#e67e22;';
        
        new obsidian.Setting(el)
            .setName('管理关系类型（可视化）')
            .setDesc('在可视化界面中添加、编辑或删除关系类型列表')
            .addButton(function (btn) {
                btn.setButtonText('📌 管理关系类型')
                    .setCta()
                    .onClick(function () {
                        var modal = new RelationTypeModal(self.app, self.plugin, function() {
                            refreshCharView(self.app);
                        });
                        modal.open();
                    });
            });

        el.createEl('hr');

        el.createEl('h3', { text: '❤️ 亲密度等级配置' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;color:#e74c3c;';

        new obsidian.Setting(el)
            .setName('管理亲密度等级（可视化）')
            .setDesc('在可视化界面中添加、编辑或删除亲密度等级')
            .addButton(function (btn) {
                btn.setButtonText('❤️ 管理亲密度等级')
                    .setCta()
                    .onClick(function () {
                        var modal = new IntimacyLevelModal(self.app, self.plugin, function() {
                            refreshCharView(self.app);
                        });
                        modal.open();
                    });
            });

        el.createEl('hr');

        el.createEl('h3', { text: '⚙️ 其他配置' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;color:#888;';

        new obsidian.Setting(el)
            .setName('人物字段显示顺序')
            .setDesc('自定义人物详情中字段的显示顺序，用逗号分隔')
            .addText(function (text) {
                text.setPlaceholder('身份,阵营,出生,死亡,亲密人物,首次出场')
                    .setValue(this.plugin.settings.customFields || '')
                    .onChange(async function (value) {
                        this.plugin.settings.customFields = value;
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('阵营字段名')
            .setDesc('人物文件中用于标识阵营的字段名')
            .addText(function (text) {
                text.setPlaceholder('阵营')
                    .setValue(this.plugin.settings.factionFieldName || '阵营')
                    .onChange(async function (value) {
                        this.plugin.settings.factionFieldName = value || '阵营';
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('死亡字段名')
            .setDesc('人物文件中用于标识死亡的字段名（支持多个，用逗号分隔）')
            .addText(function (text) {
                text.setPlaceholder('死亡,死亡时间')
                    .setValue(this.plugin.settings.deathFieldNames || '死亡,死亡时间')
                    .onChange(async function (value) {
                        this.plugin.settings.deathFieldNames = value || '死亡,死亡时间';
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('出生字段名')
            .setDesc('人物文件中用于标识出生的字段名（支持多个，用逗号分隔）')
            .addText(function (text) {
                text.setPlaceholder('出生,出生时间')
                    .setValue(this.plugin.settings.birthFieldNames || '出生,出生时间')
                    .onChange(async function (value) {
                        this.plugin.settings.birthFieldNames = value || '出生,出生时间';
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('首次出场字段名')
            .setDesc('人物文件中用于标识首次出场的字段名')
            .addText(function (text) {
                text.setPlaceholder('首次出场')
                    .setValue(this.plugin.settings.firstAppearFieldName || '首次出场')
                    .onChange(async function (value) {
                        this.plugin.settings.firstAppearFieldName = value || '首次出场';
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        new obsidian.Setting(el)
            .setName('亲密人物字段名')
            .setDesc('人物文件中用于标识亲密人物的字段名')
            .addText(function (text) {
                text.setPlaceholder('亲密人物')
                    .setValue(this.plugin.settings.intimateFieldName || '亲密人物')
                    .onChange(async function (value) {
                        this.plugin.settings.intimateFieldName = value || '亲密人物';
                        await this.plugin.saveSettings();
                    }.bind(this));
            }.bind(this));

        el.createEl('hr');

        el.createEl('h3', { text: '🎨 配置预设' }).style.cssText = 'margin-top:10px;font-size:14px;font-weight:bold;';
        
        new obsidian.Setting(el)
            .setName('快速切换预设')
            .setDesc('选择预设模板快速填充上面的配置（仅影响字段配置，不影响路径设置）')
            .addDropdown(function (dropdown) {
                dropdown.addOption('default', '默认（中国古风）');
                dropdown.addOption('fantasy', '西幻题材');
                dropdown.addOption('modern', '现代都市');
                dropdown.addOption('scifi', '科幻题材');
                dropdown.setValue(this.plugin.settings.preset || 'default');
                dropdown.onChange(async function (value) {
                    this.plugin.settings.preset = value;
                    
                    if (value === 'fantasy') {
                        this.plugin.settings.factionFieldName = '势力';
                        this.plugin.settings.customRelationTypes = '同盟,敌对,隶属,师徒,主仆,战友,宿敌';
                        this.plugin.settings.deathFieldNames = '陨落,死亡';
                        this.plugin.settings.birthFieldNames = '诞生,出生';
                        this.plugin.settings.firstAppearFieldName = '登场';
                        this.plugin.settings.intimateFieldName = '羁绊';
                    } else if (value === 'modern') {
                        this.plugin.settings.factionFieldName = '所属组织';
                        this.plugin.settings.customRelationTypes = '同事,上下级,朋友,恋人,家人,竞争对手';
                        this.plugin.settings.deathFieldNames = '去世,死亡';
                        this.plugin.settings.birthFieldNames = '出生';
                        this.plugin.settings.firstAppearFieldName = '首次出现';
                        this.plugin.settings.intimateFieldName = '亲密关系';
                    } else if (value === 'scifi') {
                        this.plugin.settings.factionFieldName = '所属势力';
                        this.plugin.settings.customRelationTypes = '同盟,敌对,从属,克隆,共生,竞争';
                        this.plugin.settings.deathFieldNames = '阵亡,销毁,死亡';
                        this.plugin.settings.birthFieldNames = '制造,出生,激活';
                        this.plugin.settings.firstAppearFieldName = '首次登场';
                        this.plugin.settings.intimateFieldName = '情感链接';
                    } else {
                        this.plugin.settings.factionFieldName = '阵营';
                        this.plugin.settings.customRelationTypes = '';
                        this.plugin.settings.deathFieldNames = '死亡,死亡时间';
                        this.plugin.settings.birthFieldNames = '出生,出生时间';
                        this.plugin.settings.firstAppearFieldName = '首次出场';
                        this.plugin.settings.intimateFieldName = '亲密人物';
                    }
                    
                    await this.plugin.saveSettings();
                    new obsidian.Notice('已切换预设，请刷新人物视图查看效果');
                }.bind(this));
            }.bind(this));

        var testBtn = el.createEl('button', { text: '🔍 测试文件路径' });
        testBtn.style.cssText = 'margin-top:15px;padding:8px 16px;background:#4a90e2;color:white;border:none;border-radius:4px;cursor:pointer;width:100%;';
        testBtn.addEventListener('click', async function() {
            var fullCharPath = getCharFullPath(this.plugin);
            var fullTimelinePath = getTimelineFullPath(this.plugin);
            
            var charExists = await this.app.vault.adapter.exists(fullCharPath);
            var timelineExists = await this.app.vault.adapter.exists(fullTimelinePath);
            
            var msg = '📁 路径测试结果：\n\n';
            msg += '👥 人物文件: ' + fullCharPath + '\n';
            msg += '   存在: ' + (charExists ? '✅ 是' : '❌ 否') + '\n\n';
            msg += '📅 时间线文件: ' + fullTimelinePath + '\n';
            msg += '   存在: ' + (timelineExists ? '✅ 是' : '❌ 否');
            
            new obsidian.Notice(msg, 8000);
        }.bind(this));

        el.createEl('h3', { text: '📖 文件格式示例' }).style.cssText = 'margin-top:20px;font-size:14px;font-weight:bold;';
        
        var formatNote = el.createEl('pre');
        formatNote.style.cssText = 'background:#f5f5f5;padding:10px;border-radius:6px;font-size:12px;overflow-x:auto;';
        formatNote.textContent = '## 张三\n' +
            '- 身份：皇帝\n' +
            '- 阵营：北境王国\n' +
            '- 首次出场：公元前300年\n' +
            '- 出生：公元前280年\n' +
            '- 死亡：前200年\n' +
            '- 亲密人物：李四\n' +
            '- 自定义字段：任意值\n\n' +
            '## 李四\n' +
            '- 身份：将军\n' +
            '- 阵营：北境王国\n' +
            '- 出生：290年\n\n' +
            '💡 时间支持：公元前280年、前100年、280年、公元100年';

        var timelineNote = el.createEl('pre');
        timelineNote.style.cssText = 'background:#f5f5f5;padding:10px;border-radius:6px;font-size:12px;overflow-x:auto;margin-top:10px;';
        timelineNote.textContent = '## 300年\n' +
            '### 春季：\n' +
            '- [战争] 张三率军出征\n' +
            '- [政治] 李四受封将军\n\n' +
            '### 秋季：\n' +
            '- [婚恋] 张三与某公主成婚\n\n' +
            '💡 标签使用 [标签名] 格式，标签名可在上方自定义';

        el.createEl('p', {
            text: '💾 阵营和关系数据保存在 .obsidian/plugins/' + this.plugin.manifest.id + '/data.json'
        }).style.cssText = 'color:#888;font-size:12px;margin-top:15px;';
    };

    return SettingTab;
}(obsidian.PluginSettingTab));

// ========== 主插件 ==========
var MyPlugin = /** @class */ (function (_super) {
    __extends(MyPlugin, _super);
    function MyPlugin() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    MyPlugin.prototype.onload = async function () {
        await this.loadSettings();

        this.registerView(VIEW_TYPE, function (leaf) {
            return new MyView(leaf, this);
        }.bind(this));

        this.addRibbonIcon('users', '人物关系', function () {
            openCharView(this.app);
        }.bind(this));

        this.addCommand({
            id: 'open-char-view',
            name: '打开人物关系视图',
            callback: function () {
                openCharView(this.app);
            }.bind(this)
        });

        this.addCommand({
            id: 'refresh-char-data',
            name: '刷新人物数据',
            callback: function () {
                refreshCharView(this.app);
            }.bind(this)
        });

        var pluginRef = this;
        this.registerEvent(this.app.vault.on('modify', function(file) {
            var charPath = getCharFullPath(pluginRef);
            var timelinePath = getTimelineFullPath(pluginRef);
            if (file.path === charPath || file.path === timelinePath) {
                refreshCharView(pluginRef.app, { silent: true });
            }
        }));

        this.addSettingTab(new SettingTab(this.app, this));
    };

    MyPlugin.prototype.onunload = function () {
        this.app.workspace.detachLeavesOfType(VIEW_TYPE);
    };

    MyPlugin.prototype.loadSettings = async function () {
        var defaults = { 
            charFile: '人物索引.md',
            charFolder: '',
            timelineFile: '时间线.md',
            timelineFolder: '',
            customFields: '',
            customRelationTypes: '',
            factionFieldName: '阵营',
            deathFieldNames: '死亡,死亡时间',
            birthFieldNames: '出生,出生时间',
            firstAppearFieldName: '首次出场',
            intimateFieldName: '亲密人物',
            preset: 'default',
            customEventTags: [],
            customIntimacyLevels: ''
        };
        this.settings = Object.assign({}, defaults, await this.loadData());
    };

    MyPlugin.prototype.saveSettings = async function () {
        await this.saveData(this.settings);
    };

    return MyPlugin;
}(obsidian.Plugin));

module.exports = MyPlugin;

function __extends(d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}